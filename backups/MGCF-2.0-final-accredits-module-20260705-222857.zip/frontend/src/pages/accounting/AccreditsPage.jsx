import {
  ArrowTrendingDownIcon,
  ArrowTrendingUpIcon,
  BanknotesIcon,
  CalculatorIcon,
  PencilSquareIcon,
  PlusIcon,
  TrashIcon,
} from "@heroicons/react/24/outline";
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";

import { getAccounts } from "../../services/accountService";
import { createAccredit, deleteAccredit, getAccredits, updateAccredit } from "../../services/accreditService";
import { getManagedItems } from "../../services/managedItemService";

const currency = new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR" });
const dateFormatter = new Intl.DateTimeFormat("it-IT");

function localDate() {
  const date = new Date();
  const offset = date.getTimezoneOffset() * 60000;
  return new Date(date.getTime() - offset).toISOString().slice(0, 10);
}

function emptyForm() {
  return { movementDate: localDate(), amount: "", accountId: "", causeId: "", notes: "" };
}

function errorMessage(error, fallback) {
  return error.response?.data?.message ?? fallback;
}

function monthKey(date) {
  return String(date).slice(0, 7);
}

function previousMonthKey() {
  const date = new Date();
  date.setDate(1);
  date.setMonth(date.getMonth() - 1);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

export default function AccreditsPage() {
  const [accredits, setAccredits] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [causes, setCauses] = useState([]);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [fields, setFields] = useState(emptyForm);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState({ text: "", error: false });

  useEffect(() => {
    Promise.all([getAccredits(), getAccounts(), getManagedItems("cause")])
      .then(([accreditData, accountData, causeData]) => {
        setAccredits(accreditData);
        setAccounts(accountData);
        setCauses(causeData);
      })
      .catch((error) => setMessage({ text: errorMessage(error, "Impossibile caricare i dati."), error: true }))
      .finally(() => setLoading(false));
  }, []);

  const metrics = useMemo(() => {
    const total = accredits.reduce((sum, item) => sum + Number(item.amount), 0);
    const currentKey = monthKey(localDate());
    const previousKey = previousMonthKey();
    const currentMonth = accredits.filter((item) => monthKey(item.movementDate) === currentKey).reduce((sum, item) => sum + Number(item.amount), 0);
    const previousMonth = accredits.filter((item) => monthKey(item.movementDate) === previousKey).reduce((sum, item) => sum + Number(item.amount), 0);
    const byAccount = Object.values(accredits.reduce((result, item) => {
      const key = item.accountId;
      result[key] ??= { accountId: key, accountName: item.accountName, count: 0, total: 0 };
      result[key].count += 1;
      result[key].total += Number(item.amount);
      return result;
    }, {})).sort((first, second) => second.total - first.total);
    return {
      total,
      count: accredits.length,
      average: accredits.length ? total / accredits.length : 0,
      currentMonth,
      previousMonth,
      difference: currentMonth - previousMonth,
      percentage: previousMonth ? ((currentMonth - previousMonth) / previousMonth) * 100 : null,
      byAccount,
    };
  }, [accredits]);

  function openNew() {
    setEditing(null);
    setFields(emptyForm());
    setFormOpen(true);
    setMessage({ text: "", error: false });
  }

  function openEdit(item) {
    setEditing(item);
    setFields({ movementDate: String(item.movementDate).slice(0, 10), amount: item.amount, accountId: String(item.accountId), causeId: item.causeId ? String(item.causeId) : "", notes: item.notes ?? "" });
    setFormOpen(true);
    setMessage({ text: "", error: false });
  }

  function closeForm() {
    setFormOpen(false);
    setEditing(null);
  }

  async function save(event) {
    event.preventDefault();
    setSaving(true);
    try {
      const saved = editing ? await updateAccredit(editing.id, fields) : await createAccredit(fields);
      setAccredits((current) => {
        const next = editing ? current.map((item) => (item.id === saved.id ? saved : item)) : [saved, ...current];
        return next.sort((first, second) => String(second.movementDate).localeCompare(String(first.movementDate)) || second.id - first.id);
      });
      closeForm();
      setMessage({ text: "Accredito salvato correttamente.", error: false });
    } catch (error) {
      setMessage({ text: errorMessage(error, "Impossibile salvare l'accredito."), error: true });
    } finally {
      setSaving(false);
    }
  }

  async function confirmDelete() {
    setSaving(true);
    try {
      await deleteAccredit(deleting.id);
      setAccredits((current) => current.filter((item) => item.id !== deleting.id));
      setMessage({ text: "Accredito eliminato.", error: false });
    } catch (error) {
      setMessage({ text: errorMessage(error, "Impossibile eliminare l'accredito."), error: true });
    } finally {
      setDeleting(null);
      setSaving(false);
    }
  }

  const activeAccounts = accounts.filter((account) => account.active || String(account.id) === fields.accountId);
  const activeCauses = causes.filter((cause) => cause.active || String(cause.id) === fields.causeId);

  return (
    <div className="mx-auto max-w-6xl">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-3">
            <BanknotesIcon className="h-8 w-8 text-amber-500" />
            <h1 className="text-3xl font-bold text-slate-900">Inserisci accredito</h1>
          </div>
          <p className="mt-2 text-slate-500">Registra gli accrediti e controlla andamento, conti e importi.</p>
        </div>
        <button type="button" onClick={openNew} className="flex items-center justify-center gap-2 rounded-md bg-amber-500 px-6 py-3 font-semibold text-white transition-colors hover:bg-amber-600">
          <PlusIcon className="h-5 w-5" /> Nuovo accredito
        </button>
      </div>

      {message.text && <p className={`mt-6 rounded-md px-4 py-3 text-sm font-medium ${message.error ? "bg-red-50 text-red-700" : "bg-emerald-50 text-emerald-700"}`}>{message.text}</p>}

      {formOpen && (
        <form onSubmit={save} className="mt-8 rounded-lg border border-slate-200 bg-white p-8">
          <h2 className="text-xl font-semibold text-slate-900">{editing ? "Modifica accredito" : "Nuovo accredito"}</h2>
          <div className="mt-6 grid grid-cols-1 gap-6 md:grid-cols-2">
            <label className="text-sm font-medium text-slate-700">Data accredito *<input type="date" required value={fields.movementDate} onChange={(event) => setFields((current) => ({ ...current, movementDate: event.target.value }))} className="mt-2 w-full rounded-md border border-slate-300 px-4 py-3 outline-none focus:border-amber-500" /></label>
            <label className="text-sm font-medium text-slate-700">Importo accredito *<input type="number" required min="0.01" step="0.01" value={fields.amount} onChange={(event) => setFields((current) => ({ ...current, amount: event.target.value }))} placeholder="0,00" className="mt-2 w-full rounded-md border border-slate-300 px-4 py-3 outline-none focus:border-amber-500" /></label>
            <label className="text-sm font-medium text-slate-700">Conto / banca *<select required value={fields.accountId} onChange={(event) => setFields((current) => ({ ...current, accountId: event.target.value }))} className="mt-2 w-full rounded-md border border-slate-300 bg-white px-4 py-3 outline-none focus:border-amber-500"><option value="">Seleziona un conto</option>{activeAccounts.map((account) => <option key={account.id} value={account.id}>{account.name}{account.bank ? ` · ${account.bank}` : ""}</option>)}</select></label>
            <label className="text-sm font-medium text-slate-700">Causale accredito *<select required value={fields.causeId} onChange={(event) => setFields((current) => ({ ...current, causeId: event.target.value }))} className="mt-2 w-full rounded-md border border-slate-300 bg-white px-4 py-3 outline-none focus:border-amber-500"><option value="">Seleziona una causale</option>{activeCauses.map((cause) => <option key={cause.id} value={cause.id}>{cause.name}</option>)}</select><Link to="/settings/causes" className="mt-2 inline-block text-xs text-amber-700 hover:text-amber-900">Gestisci causali</Link></label>
            <label className="text-sm font-medium text-slate-700 md:col-span-2">Note<textarea rows="3" value={fields.notes} onChange={(event) => setFields((current) => ({ ...current, notes: event.target.value }))} placeholder="Nota facoltativa" className="mt-2 w-full rounded-md border border-slate-300 px-4 py-3 outline-none focus:border-amber-500" /></label>
          </div>
          <div className="mt-8 flex justify-end gap-3"><button type="button" onClick={closeForm} className="rounded-md border border-slate-300 px-6 py-3 font-semibold text-slate-700 hover:bg-slate-50">Annulla</button><button type="submit" disabled={saving || activeAccounts.length === 0 || activeCauses.length === 0} className="rounded-md bg-amber-500 px-6 py-3 font-semibold text-white hover:bg-amber-600 disabled:opacity-60">{saving ? "Salvataggio..." : "Salva accredito"}</button></div>
        </form>
      )}

      <div className="mt-8 grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard label="Importo totale" value={currency.format(metrics.total)} icon={BanknotesIcon} />
        <MetricCard label="Numero accrediti" value={String(metrics.count)} icon={CalculatorIcon} />
        <MetricCard label="Media accrediti" value={currency.format(metrics.average)} icon={CalculatorIcon} />
        <MetricCard label="Mese corrente" value={currency.format(metrics.currentMonth)} detail={`Mese precedente: ${currency.format(metrics.previousMonth)}${metrics.percentage === null ? "" : ` · ${metrics.percentage >= 0 ? "+" : ""}${metrics.percentage.toFixed(1)}%`}`} icon={metrics.difference >= 0 ? ArrowTrendingUpIcon : ArrowTrendingDownIcon} positive={metrics.difference >= 0} />
      </div>

      <div className="mt-8 rounded-lg border border-slate-200 bg-white">
        <div className="border-b border-slate-200 px-6 py-5"><h2 className="text-lg font-semibold text-slate-900">Riepilogo per conto</h2><p className="mt-1 text-sm text-slate-500">Numero e importo complessivo degli accrediti ricevuti.</p></div>
        {metrics.byAccount.length ? <div className="divide-y divide-slate-100">{metrics.byAccount.map((account) => <div key={account.accountId} className="grid grid-cols-[1fr_auto_auto] items-center gap-6 px-6 py-4 text-sm"><span className="font-medium text-slate-800">{account.accountName}</span><span className="text-slate-500">{account.count} accrediti</span><span className="font-semibold text-slate-900">{currency.format(account.total)}</span></div>)}</div> : <p className="px-6 py-5 text-sm text-slate-400">Nessun accredito registrato</p>}
      </div>

      <div className="mt-8 overflow-hidden rounded-lg border border-slate-200 bg-white">
        <div className="border-b border-slate-200 px-6 py-5"><h2 className="text-lg font-semibold text-slate-900">Storico accrediti</h2><p className="mt-1 text-sm text-slate-500">Tutte le registrazioni, dalla più recente.</p></div>
        {loading ? <p className="px-6 py-5 text-sm text-slate-500">Caricamento...</p> : accredits.length ? <div className="divide-y divide-slate-100">{accredits.map((item) => <article key={item.id} className="flex flex-col gap-3 px-6 py-4 lg:flex-row lg:items-center"><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-3"><h3 className="font-semibold text-slate-900">{item.causeName}</h3><span className="text-xs text-slate-400">{dateFormatter.format(new Date(`${String(item.movementDate).slice(0, 10)}T00:00:00`))}</span></div><p className="mt-1 text-sm text-slate-500">{item.accountName}{item.notes ? ` · ${item.notes}` : ""}</p></div><strong className="text-slate-900">{currency.format(Number(item.amount))}</strong><div className="flex items-center gap-1"><button type="button" onClick={() => openEdit(item)} aria-label={`Modifica accredito ${item.causeName}`} className="flex h-8 w-8 items-center justify-center rounded-md text-slate-500 hover:bg-amber-50 hover:text-amber-700"><PencilSquareIcon className="h-[18px] w-[18px]" /></button><button type="button" onClick={() => setDeleting(item)} aria-label={`Elimina accredito ${item.causeName}`} className="flex h-8 w-8 items-center justify-center rounded-md text-red-500 hover:bg-red-50 hover:text-red-700"><TrashIcon className="h-[18px] w-[18px]" /></button></div></article>)}</div> : <p className="px-6 py-8 text-center text-sm text-slate-400">Nessun accredito registrato</p>}
      </div>

      {deleting && <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/40 p-6"><div className="w-full max-w-md rounded-lg border border-slate-200 bg-white p-8"><h2 className="text-xl font-semibold text-slate-900">Eliminare l'accredito?</h2><p className="mt-3 text-sm text-slate-600">L'accredito di <strong>{currency.format(Number(deleting.amount))}</strong> verrà eliminato definitivamente.</p><div className="mt-8 flex justify-end gap-3"><button type="button" onClick={() => setDeleting(null)} disabled={saving} className="rounded-md border border-slate-300 px-5 py-3 font-semibold text-slate-700 hover:bg-slate-50">Annulla</button><button type="button" onClick={confirmDelete} disabled={saving} className="rounded-md bg-red-600 px-5 py-3 font-semibold text-white hover:bg-red-700 disabled:opacity-60">{saving ? "Eliminazione..." : "Elimina"}</button></div></div></div>}
    </div>
  );
}

function MetricCard({ label, value, detail, icon: Icon, positive = true }) {
  return (
    <div className="rounded-lg border border-slate-200 bg-white p-5">
      <div className="flex items-center justify-between"><p className="text-xs font-medium uppercase tracking-wide text-slate-400">{label}</p><Icon className={`h-5 w-5 ${positive ? "text-amber-600" : "text-red-500"}`} /></div>
      <p className="mt-3 text-2xl font-semibold text-slate-900">{value}</p>
      {detail && <p className={`mt-1 text-xs ${positive ? "text-emerald-600" : "text-red-600"}`}>{detail}</p>}
    </div>
  );
}
