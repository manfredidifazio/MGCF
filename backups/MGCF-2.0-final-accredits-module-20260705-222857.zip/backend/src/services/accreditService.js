import pool from "../database/database.js";

const selectAccredits = `
  SELECT
    ac.id,
    ac.account_id AS "accountId",
    ac.cause_id AS "causeId",
    ac.movement_date AS "movementDate",
    ac.description,
    ac.amount,
    ac.notes,
    ac.created_at AS "createdAt",
    ac.updated_at AS "updatedAt",
    a.name AS "accountName",
    COALESCE(c.name, ac.description) AS "causeName"
  FROM accredits ac
  JOIN accounts a ON a.id = ac.account_id
  LEFT JOIN managed_items c ON c.id = ac.cause_id AND c.type = 'cause'
`;

export async function ensureAccreditsStructure() {
  await pool.query(`
    ALTER TABLE accredits
      ADD COLUMN IF NOT EXISTS cause_id INTEGER REFERENCES managed_items(id) ON DELETE SET NULL
  `);
  await pool.query(`
    CREATE INDEX IF NOT EXISTS accredits_movement_date_idx ON accredits (movement_date DESC);
    CREATE INDEX IF NOT EXISTS accredits_account_id_idx ON accredits (account_id);
    CREATE INDEX IF NOT EXISTS accredits_cause_id_idx ON accredits (cause_id)
  `);
}

export async function getAccredits() {
  const result = await pool.query(`${selectAccredits} ORDER BY ac.movement_date DESC, ac.id DESC`);
  return result.rows;
}

async function validReferences(accountId, causeId) {
  const result = await pool.query(
    `
      SELECT a.id AS "accountId", c.id AS "causeId", c.name AS "causeName"
      FROM accounts a
      CROSS JOIN managed_items c
      WHERE a.id = $1 AND a.active = TRUE
        AND c.id = $2 AND c.type = 'cause' AND c.active = TRUE
    `,
    [accountId, causeId]
  );
  return result.rows[0] ?? null;
}

async function getAccredit(id) {
  const result = await pool.query(`${selectAccredits} WHERE ac.id = $1`, [id]);
  return result.rows[0] ?? null;
}

export async function createAccredit(accredit) {
  const references = await validReferences(accredit.accountId, accredit.causeId);
  if (!references) return null;
  const result = await pool.query(
    `
      INSERT INTO accredits (account_id, cause_id, movement_date, description, amount, notes)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING id
    `,
    [accredit.accountId, accredit.causeId, accredit.movementDate, references.causeName, accredit.amount, accredit.notes]
  );
  return getAccredit(result.rows[0].id);
}

export async function updateAccredit(id, accredit) {
  const references = await validReferences(accredit.accountId, accredit.causeId);
  if (!references) return null;
  const result = await pool.query(
    `
      UPDATE accredits
      SET account_id = $1,
          cause_id = $2,
          movement_date = $3,
          description = $4,
          amount = $5,
          notes = $6,
          updated_at = CURRENT_TIMESTAMP
      WHERE id = $7
      RETURNING id
    `,
    [accredit.accountId, accredit.causeId, accredit.movementDate, references.causeName, accredit.amount, accredit.notes, id]
  );
  if (result.rows.length === 0) return undefined;
  return getAccredit(id);
}

export async function deleteAccredit(id) {
  const result = await pool.query("DELETE FROM accredits WHERE id = $1 RETURNING id", [id]);
  return result.rows.length > 0;
}
