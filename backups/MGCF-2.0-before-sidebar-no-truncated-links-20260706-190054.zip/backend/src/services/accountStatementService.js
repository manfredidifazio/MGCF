import pool from "../database/database.js";

const fields = `
  s.id,
  s.account_id AS "accountId",
  s.period,
  s.previous_balance AS "previousBalance",
  s.current_balance AS "currentBalance",
  s.notes,
  s.created_at AS "createdAt",
  s.updated_at AS "updatedAt",
  a.name AS "accountName",
  a.bank,
  a.color AS "accountColor"
`;

export async function ensureAccountStatementsTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS account_statements (
      id SERIAL PRIMARY KEY,
      account_id INTEGER NOT NULL REFERENCES accounts(id) ON DELETE RESTRICT,
      period DATE NOT NULL,
      previous_balance NUMERIC(14, 2) NOT NULL,
      current_balance NUMERIC(14, 2) NOT NULL,
      notes TEXT,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE (account_id, period)
    )
  `);
  await pool.query(`
    CREATE INDEX IF NOT EXISTS account_statements_period_idx ON account_statements (period DESC);
    CREATE INDEX IF NOT EXISTS account_statements_account_idx ON account_statements (account_id, period DESC)
  `);
}

export async function getAccountStatements() {
  const result = await pool.query(`
    SELECT ${fields}
    FROM account_statements s
    JOIN accounts a ON a.id = s.account_id
    ORDER BY s.period DESC, a.name ASC
  `);
  return result.rows;
}

async function exactPrevious(client, accountId, period, excludedId = null) {
  const result = await client.query(
    `
      SELECT current_balance AS "currentBalance"
      FROM account_statements
      WHERE account_id = $1
        AND period = ($2::date - INTERVAL '1 month')::date
        AND ($3::integer IS NULL OR id <> $3)
    `,
    [accountId, period, excludedId]
  );
  return result.rows[0]?.currentBalance;
}

async function alignNext(client, accountId, period, currentBalance) {
  await client.query(
    `
      UPDATE account_statements
      SET previous_balance = $1, updated_at = CURRENT_TIMESTAMP
      WHERE account_id = $2 AND period = ($3::date + INTERVAL '1 month')::date
    `,
    [currentBalance, accountId, period]
  );
}

async function getById(client, id) {
  const result = await client.query(
    `SELECT ${fields} FROM account_statements s JOIN accounts a ON a.id = s.account_id WHERE s.id = $1`,
    [id]
  );
  return result.rows[0] ?? null;
}

export async function createAccountStatement(statement) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const account = await client.query("SELECT id FROM accounts WHERE id = $1 AND active = TRUE", [statement.accountId]);
    if (account.rows.length === 0) {
      await client.query("ROLLBACK");
      return null;
    }
    const previous = await exactPrevious(client, statement.accountId, statement.period);
    const previousBalance = previous ?? statement.previousBalance;
    const result = await client.query(
      `
        INSERT INTO account_statements (account_id, period, previous_balance, current_balance, notes)
        VALUES ($1, $2, $3, $4, $5)
        RETURNING id
      `,
      [statement.accountId, statement.period, previousBalance, statement.currentBalance, statement.notes]
    );
    await alignNext(client, statement.accountId, statement.period, statement.currentBalance);
    const created = await getById(client, result.rows[0].id);
    await client.query("COMMIT");
    return created;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

export async function updateAccountStatement(id, statement) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const existing = await client.query(
      `SELECT account_id AS "accountId", period, previous_balance AS "previousBalance" FROM account_statements WHERE id = $1`,
      [id]
    );
    if (existing.rows.length === 0) {
      await client.query("ROLLBACK");
      return null;
    }
    const current = existing.rows[0];
    const account = await client.query("SELECT id FROM accounts WHERE id = $1", [statement.accountId]);
    if (account.rows.length === 0) {
      await client.query("ROLLBACK");
      return null;
    }

    const oldPrevious = await exactPrevious(client, current.accountId, current.period, id);
    await alignNext(client, current.accountId, current.period, oldPrevious ?? current.previousBalance);

    const newPrevious = await exactPrevious(client, statement.accountId, statement.period, id);
    const previousBalance = newPrevious ?? statement.previousBalance;
    await client.query(
      `
        UPDATE account_statements
        SET account_id = $1,
            period = $2,
            previous_balance = $3,
            current_balance = $4,
            notes = $5,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = $6
      `,
      [statement.accountId, statement.period, previousBalance, statement.currentBalance, statement.notes, id]
    );
    await alignNext(client, statement.accountId, statement.period, statement.currentBalance);
    const updated = await getById(client, id);
    await client.query("COMMIT");
    return updated;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

export async function deleteAccountStatement(id) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const existing = await client.query(
      `SELECT account_id AS "accountId", period, previous_balance AS "previousBalance" FROM account_statements WHERE id = $1`,
      [id]
    );
    if (existing.rows.length === 0) {
      await client.query("ROLLBACK");
      return false;
    }
    const statement = existing.rows[0];
    await client.query("DELETE FROM account_statements WHERE id = $1", [id]);
    const previous = await exactPrevious(client, statement.accountId, statement.period);
    await alignNext(client, statement.accountId, statement.period, previous ?? statement.previousBalance);
    await client.query("COMMIT");
    return true;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}
