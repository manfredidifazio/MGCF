import logo from "../../assets/logo.png";

export default function Logo() {
  return (
    <img
      src={logo}
      alt="MGCF Gestionale Contabile"
      className="h-16 w-auto object-contain select-none"
      draggable={false}
    />
  );
}