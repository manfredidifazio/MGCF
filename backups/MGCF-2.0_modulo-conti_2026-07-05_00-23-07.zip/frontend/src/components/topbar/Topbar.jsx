import { BellIcon } from "@heroicons/react/24/outline";

import logoMGCF from "../../assets/logo.png";
import SettingsMenu from "./SettingsMenu";
import UserMenu from "./UserMenu";

export default function Topbar() {
  return (
    <header className="flex h-20 items-center justify-between border-b border-slate-200 bg-white px-8">
      <img
        src={logoMGCF}
        alt="MGCF"
        className="h-16 w-auto select-none object-contain"
        draggable={false}
      />

      <div className="flex items-center gap-4">
        <button
          type="button"
          aria-label="Notifiche"
          className="relative flex h-11 w-11 items-center justify-center rounded-xl border border-slate-200 bg-white transition hover:bg-slate-50"
        >
          <BellIcon className="h-6 w-6 text-slate-700" />
          <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-amber-500 text-[10px] font-bold text-white">
            3
          </span>
        </button>

        <SettingsMenu />
        <UserMenu />
      </div>
    </header>
  );
}
