import { Menu } from "@headlessui/react";
import {
  Bars3BottomLeftIcon,
  BuildingLibraryIcon,
  ChevronDownIcon,
  Cog6ToothIcon,
  HomeModernIcon,
  ReceiptPercentIcon,
  TruckIcon,
} from "@heroicons/react/24/outline";
import { useNavigate } from "react-router-dom";

const items = [
  { label: "Conti", icon: BuildingLibraryIcon, path: "/settings/accounts" },
  { label: "Tasse", icon: ReceiptPercentIcon },
  { label: "Immobili", icon: HomeModernIcon },
  { label: "Veicoli", icon: TruckIcon },
  { label: "Causali", icon: Bars3BottomLeftIcon },
];

export default function SettingsMenu() {
  const navigate = useNavigate();

  return (
    <Menu as="div" className="relative">
      <Menu.Button className="flex h-11 items-center gap-3 rounded-xl border border-slate-200 bg-white px-5 transition hover:bg-slate-50">
        <Cog6ToothIcon className="h-5 w-5 text-slate-600" />
        <span className="font-semibold">IMPOSTAZIONI</span>
        <ChevronDownIcon className="h-4 w-4 text-slate-500" />
      </Menu.Button>

      <Menu.Items className="absolute right-0 z-50 mt-2 w-60 overflow-hidden rounded-2xl border border-slate-200 bg-white py-2 shadow-xl focus:outline-none">
        {items.map((item) => {
          const Icon = item.icon;

          return (
            <Menu.Item key={item.label}>
              {({ focus }) => (
                <button
                  type="button"
                  onClick={() => item.path && navigate(item.path)}
                  className={`flex w-full items-center gap-3 px-5 py-3 text-left transition ${focus ? "bg-slate-100" : ""}`}
                >
                  <Icon className="h-5 w-5 text-slate-600" />
                  <span className="font-medium text-slate-800">{item.label}</span>
                </button>
              )}
            </Menu.Item>
          );
        })}
      </Menu.Items>
    </Menu>
  );
}
