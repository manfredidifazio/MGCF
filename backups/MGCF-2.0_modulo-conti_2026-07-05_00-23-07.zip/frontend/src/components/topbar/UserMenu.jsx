import { Menu } from "@headlessui/react";
import {
  ArrowRightStartOnRectangleIcon,
  ChevronDownIcon,
  ShieldCheckIcon,
} from "@heroicons/react/24/outline";
import { useNavigate } from "react-router-dom";

export default function UserMenu() {
  const navigate = useNavigate();

  function handleLogout() {
    localStorage.removeItem("token");
    navigate("/", { replace: true });
  }

  return (
    <Menu as="div" className="relative">
      <Menu.Button className="flex h-11 items-center gap-3 rounded-xl border border-slate-200 bg-white px-4 transition hover:bg-slate-50">
        <span className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-900 text-sm font-semibold text-white">
          M
        </span>
        <span className="font-semibold">MANFREDI D.</span>
        <ChevronDownIcon className="h-4 w-4 text-slate-500" />
      </Menu.Button>

      <Menu.Items className="absolute right-0 z-50 mt-2 w-64 overflow-hidden rounded-2xl border border-slate-200 bg-white py-2 shadow-xl focus:outline-none">
        <Menu.Item>
          {({ focus }) => (
            <button
              type="button"
              onClick={() => navigate("/security")}
              className={`flex w-full items-center gap-3 px-5 py-3 text-left transition ${focus ? "bg-slate-100" : ""}`}
            >
              <ShieldCheckIcon className="h-5 w-5 text-slate-600" />
              <span className="font-medium text-slate-800">Sicurezza</span>
            </button>
          )}
        </Menu.Item>

        <Menu.Item>
          {({ focus }) => (
            <button
              type="button"
              onClick={handleLogout}
              className={`flex w-full items-center gap-3 px-5 py-3 text-left text-red-600 transition ${focus ? "bg-red-50" : ""}`}
            >
              <ArrowRightStartOnRectangleIcon className="h-5 w-5" />
              <span className="font-medium">Logout</span>
            </button>
          )}
        </Menu.Item>
      </Menu.Items>
    </Menu>
  );
}
