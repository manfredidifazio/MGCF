import { Outlet } from "react-router-dom";
import Topbar from "../components/topbar/Topbar";

export default function MainLayout() {
  return (
    <div className="min-h-screen bg-slate-100">

      {/* TOPBAR */}
      <Topbar />

      <div className="flex">

        {/* SIDEBAR */}
        <aside className="w-72 bg-white border-r border-slate-200 min-h-[calc(100vh-64px)]">
        </aside>

        {/* CONTENUTO */}
        <main className="flex-1 p-8">
          <Outlet />
        </main>

      </div>

    </div>
  );
}
