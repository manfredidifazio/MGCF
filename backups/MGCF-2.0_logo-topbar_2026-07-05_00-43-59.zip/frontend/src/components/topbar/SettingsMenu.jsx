import { Menu } from "@headlessui/react";
import {
  Bars3BottomLeftIcon,
  BuildingLibraryIcon,
  ChevronDownIcon,
  Cog6ToothIcon,
  HomeModernIcon,
  ReceiptPercentIcon,
  TruckIcon,
} from "@heroicons/react/24/outline";
import { useNavigate } from "react-router-dom";

const items = [
  { label: "Conti", icon: BuildingLibraryIcon, path: "/settings/accounts" },
  { label: "Tasse", icon: ReceiptPercentIcon },
  { label: "Immobili", icon: HomeModernIcon },
  { label: "Veicoli", icon: TruckIcon },
  { label: "Causali", icon: Bars3BottomLeftIcon },
];

export default function SettingsMenu() {
  const navigate = useNavigate();

  return (
    <Menu as="div" className="relative">
      <Menu.Button className="flex h-10 items-center gap-2 rounded-xl border border-slate-900 bg-slate-900 px-4 text-sm text-white transition-all duration-200 hover:-translate-y-0.5 hover:bg-slate-700 hover:shadow-md active:translate-y-0">
        <Cog6ToothIcon className="h-5 w-5 text-slate-200" />
        <span className="font-semibold">IMPOSTAZIONI</span>
        <ChevronDownIcon className="h-4 w-4 text-slate-300" />
      </Menu.Button>

      <Menu.Items className="absolute left-1/2 z-50 mt-2 w-56 -translate-x-1/2 overflow-hidden rounded-2xl border border-slate-300 bg-white py-1.5 shadow-xl focus:outline-none">
        {items.map((item) => {
          const Icon = item.icon;

          return (
            <Menu.Item key={item.label}>
              {({ focus }) => (
                <button
                  type="button"
                  onClick={() => item.path && navigate(item.path)}
                  className={`flex w-full items-center gap-3 px-4 py-2.5 text-left text-sm transition-colors duration-150 ${focus ? "bg-amber-100 text-amber-900" : "text-slate-800"}`}
                >
                  <Icon className="h-5 w-5 text-slate-600" />
                  <span className="font-semibold">{item.label}</span>
                </button>
              )}
            </Menu.Item>
          );
        })}
      </Menu.Items>
    </Menu>
  );
}
