import {
  ArrowTrendingUpIcon,
  BanknotesIcon,
  CalculatorIcon,
  ChartBarIcon,
  ChevronDownIcon,
  DocumentTextIcon,
  ExclamationTriangleIcon,
  PencilSquareIcon,
  PlusIcon,
  TrashIcon,
} from "@heroicons/react/24/outline";
import { useEffect, useMemo, useState } from "react";

import { getAccounts } from "../../services/accountService";
import {
  createAccountStatement,
  deleteAccountStatement,
  getAccountStatements,
  updateAccountStatement,
} from "../../services/accountStatementService";

const currency = new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR" });
const months = [
  ["01", "Gennaio"], ["02", "Febbraio"], ["03", "Marzo"], ["04", "Aprile"],
  ["05", "Maggio"], ["06", "Giugno"], ["07", "Luglio"], ["08", "Agosto"],
  ["09", "Settembre"], ["10", "Ottobre"], ["11", "Novembre"], ["12", "Dicembre"],
];

function currentPeriod() {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

function previousPeriod(period) {
  const [year, month] = period.split("-").map(Number);
  const date = new Date(year, month - 2, 1);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

function periodLabel(period) {
  const [year, month] = String(period).slice(0, 7).split("-");
  return `${months.find(([value]) => value === month)?.[1] ?? month} ${year}`;
}

function emptyForm() {
  return { accountId: "", period: currentPeriod(), previousBalance: "", currentBalance: "", notes: "" };
}

function errorMessage(error, fallback) {
  return error.response?.data?.message ?? fallback;
}

export default function StatementsPage() {
  const now = currentPeriod();
  const [statements, setStatements] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [filters, setFilters] = useState({ accountId: "", month: now.slice(5, 7), year: now.slice(0, 4) });
  const [fields, setFields] = useState(emptyForm);
  const [editing, setEditing] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [formOpen, setFormOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState({ text: "", error: false });

  useEffect(() => {
    Promise.all([getAccountStatements(), getAccounts()])
      .then(([statementData, accountData]) => {
        setStatements(statementData);
        setAccounts(accountData);
      })
      .catch((error) => setMessage({ text: errorMessage(error, "Impossibile caricare gli estratti conto."), error: true }))
      .finally(() => setLoading(false));
  }, []);

  const years = useMemo(() => {
    const values = new Set(statements.map((item) => String(item.period).slice(0, 4)));
    values.add(now.slice(0, 4));
    return [...values].sort((first, second) => Number(second) - Number(first));
  }, [now, statements]);

  const filtered = useMemo(() => statements.filter((item) => {
    const period = String(item.period).slice(0, 7);
    if (filters.accountId && String(item.accountId) !== filters.accountId) return false;
    if (filters.month && period.slice(5, 7) !== filters.month) return false;
    if (filters.year && period.slice(0, 4) !== filters.year) return false;
    return true;
  }), [filters, statements]);

  const metrics = useMemo(() => {
    const totalBalance = filtered.reduce((sum, item) => sum + Number(item.currentBalance), 0);
    const totalChange = filtered.reduce((sum, item) => sum + Number(item.currentBalance) - Number(item.previousBalance), 0);
    return {
      totalBalance,
      totalChange,
      averageChange: filtered.length ? totalChange / filtered.length : 0,
      count: filtered.length,
    };
  }, [filtered]);

  const trend = useMemo(() => {
    const grouped = statements.reduce((result, item) => {
      const key = String(item.period).slice(0, 7);
      result[key] = (result[key] ?? 0) + Number(item.currentBalance);
      return result;
    }, {});
    return Object.entries(grouped).sort(([first], [second]) => first.localeCompare(second)).slice(-12).map(([period, value]) => ({ period, value }));
  }, [statements]);

  const automaticPrevious = useMemo(() => statements.find((item) =>
    item.id !== editing?.id &&
    String(item.accountId) === String(fields.accountId) &&
    String(item.period).slice(0, 7) === previousPeriod(fields.period)
  ), [editing?.id, fields.accountId, fields.period, statements]);

  const previousValue = automaticPrevious ? automaticPrevious.currentBalance : fields.previousBalance;
  const activeAccounts = accounts.filter((account) => account.active || String(account.id) === fields.accountId);
  const selectedPeriod = filters.month && filters.year ? `${filters.year}-${filters.month}` : now;

  function openNew() {
    setEditing(null);
    setFields(emptyForm());
    setFormOpen(true);
  }

  function openEdit(item) {
    setEditing(item);
    setFields({ accountId: String(item.accountId), period: String(item.period).slice(0, 7), previousBalance: item.previousBalance, currentBalance: item.currentBalance, notes: item.notes ?? "" });
    setFormOpen(true);
  }

  async function save(event) {
    event.preventDefault();
    setSaving(true);
    try {
      const payload = { ...fields, previousBalance: previousValue };
      const saved = editing ? await updateAccountStatement(editing.id, payload) : await createAccountStatement(payload);
      const refreshed = await getAccountStatements();
      setStatements(refreshed);
      setFormOpen(false);
      setEditing(null);
      setMessage({ text: `Estratto conto ${editing ? "modificato" : "registrato"} correttamente.`, error: false });
      return saved;
    } catch (error) {
      setMessage({ text: errorMessage(error, "Impossibile salvare l'estratto conto."), error: true });
    } finally {
      setSaving(false);
    }
  }

  async function confirmDelete() {
    setSaving(true);
    try {
      await deleteAccountStatement(deleting.id);
      setStatements(await getAccountStatements());
      setDeleting(null);
      setMessage({ text: "Estratto conto eliminato.", error: false });
    } catch (error) {
      setMessage({ text: errorMessage(error, "Impossibile eliminare l'estratto conto."), error: true });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="mx-auto max-w-6xl">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <div className="flex items-center gap-3"><DocumentTextIcon className="h-8 w-8 text-amber-500" /><h1 className="text-3xl font-bold text-slate-900">Gestisci estratti conto</h1></div>
          <p className="mt-2 text-slate-500">Registra i saldi mensili e controlla ricavi, perdite e patrimonio.</p>
        </div>
        <div className="flex w-max items-center gap-1.5">
          <FilterSelect width="w-32" value={filters.accountId} onChange={(value) => setFilters((current) => ({ ...current, accountId: value }))}><option value="">Tutti i conti</option>{accounts.map((account) => <option key={account.id} value={account.id}>{account.name}</option>)}</FilterSelect>
          <FilterSelect width="w-28" value={filters.month} onChange={(value) => setFilters((current) => ({ ...current, month: value }))}><option value="">Tutti i mesi</option>{months.map(([value, label]) => <option key={value} value={value}>{label}</option>)}</FilterSelect>
          <FilterSelect width="w-20" value={filters.year} onChange={(value) => setFilters((current) => ({ ...current, year: value }))}><option value="">Tutti</option>{years.map((year) => <option key={year}>{year}</option>)}</FilterSelect>
          <button type="button" onClick={openNew} className="flex h-9 items-center gap-1.5 whitespace-nowrap rounded-md bg-amber-500 px-4 text-sm font-semibold text-white hover:bg-amber-600"><PlusIcon className="h-4 w-4" />Nuovo estratto</button>
        </div>
      </div>

      {message.text && <p className={`mt-5 rounded-md px-4 py-3 text-sm ${message.error ? "bg-red-50 text-red-700" : "bg-emerald-50 text-emerald-700"}`}>{message.text}</p>}

      {formOpen && (
        <form onSubmit={save} className="mt-5 rounded-lg border border-slate-200 bg-white p-6">
          <h2 className="font-semibold text-slate-900">{editing ? "Modifica estratto conto" : "Nuovo estratto conto"}</h2>
          <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
            <FormField label="Conto *"><select required value={fields.accountId} onChange={(event) => setFields((current) => ({ ...current, accountId: event.target.value }))} className="h-10 w-full rounded-md border border-slate-300 bg-white px-3 text-sm outline-none focus:border-amber-500"><option value="">Seleziona</option>{activeAccounts.map((account) => <option key={account.id} value={account.id}>{account.name}</option>)}</select></FormField>
            <FormField label="Mese *"><input type="month" required value={fields.period} onChange={(event) => setFields((current) => ({ ...current, period: event.target.value }))} className="h-10 w-full rounded-md border border-slate-300 px-3 text-sm outline-none focus:border-amber-500" /></FormField>
            <FormField label="Saldo mese precedente *"><input type="number" step="0.01" required readOnly={Boolean(automaticPrevious)} value={previousValue} onChange={(event) => setFields((current) => ({ ...current, previousBalance: event.target.value }))} className={`h-10 w-full rounded-md border border-slate-300 px-3 text-sm outline-none ${automaticPrevious ? "bg-slate-50 text-slate-500" : "focus:border-amber-500"}`} /></FormField>
            <FormField label="Saldo mese corrente *"><input type="number" step="0.01" required value={fields.currentBalance} onChange={(event) => setFields((current) => ({ ...current, currentBalance: event.target.value }))} className="h-10 w-full rounded-md border border-slate-300 px-3 text-sm outline-none focus:border-amber-500" /></FormField>
            <label className="text-xs font-medium text-slate-600 md:col-span-2 lg:col-span-4">Note<input value={fields.notes} onChange={(event) => setFields((current) => ({ ...current, notes: event.target.value }))} className="mt-1 h-10 w-full rounded-md border border-slate-300 px-3 text-sm outline-none focus:border-amber-500" /></label>
          </div>
          {automaticPrevious && <p className="mt-2 text-xs text-slate-400">Saldo precedente compilato automaticamente da {periodLabel(automaticPrevious.period)}.</p>}
          <div className="mt-4 flex justify-end gap-2"><button type="button" onClick={() => setFormOpen(false)} className="h-9 rounded-md border border-slate-300 px-4 text-sm text-slate-700 hover:bg-slate-50">Annulla</button><button type="submit" disabled={saving} className="h-9 rounded-md bg-amber-500 px-4 text-sm font-semibold text-white hover:bg-amber-600 disabled:opacity-60">{saving ? "Salvataggio..." : "Salva"}</button></div>
        </form>
      )}

      <div className="mt-5 grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label={`Patrimonio ${periodLabel(selectedPeriod)}`} value={currency.format(metrics.totalBalance)} icon={BanknotesIcon} danger={metrics.totalBalance < 0} />
        <Stat label="Variazione totale" value={`${metrics.totalChange >= 0 ? "+" : ""}${currency.format(metrics.totalChange)}`} icon={metrics.totalChange < 0 ? ExclamationTriangleIcon : ArrowTrendingUpIcon} danger={metrics.totalChange < 0} />
        <Stat label="Variazione media" value={`${metrics.averageChange >= 0 ? "+" : ""}${currency.format(metrics.averageChange)}`} icon={CalculatorIcon} danger={metrics.averageChange < 0} />
        <Stat label="Conti rilevati" value={String(metrics.count)} icon={ChartBarIcon} />
      </div>

      <TrendChart data={trend} />

      <div className="mt-4 overflow-hidden rounded-lg border border-slate-200 bg-white">
        <div className="grid min-w-[850px] grid-cols-[130px_minmax(160px,1fr)_140px_140px_130px_72px] gap-4 border-b border-slate-200 bg-slate-50 px-5 py-2 text-[10px] font-semibold uppercase tracking-wide text-slate-400"><span>Mese</span><span>Conto</span><span className="text-right">Precedente</span><span className="text-right">Corrente</span><span className="text-right">Variazione</span><span /></div>
        {loading ? <p className="px-5 py-5 text-sm text-slate-500">Caricamento...</p> : filtered.length ? <div className="min-w-[850px] divide-y divide-slate-100">{filtered.map((item) => {
          const change = Number(item.currentBalance) - Number(item.previousBalance);
          return <div key={item.id} className="grid grid-cols-[130px_minmax(160px,1fr)_140px_140px_130px_72px] items-center gap-4 px-5 py-2.5 text-[13px]"><span className="text-slate-500">{periodLabel(item.period)}</span><span className="flex items-center gap-2 truncate font-semibold" style={{ color: item.accountColor || "#475569" }}><i className="h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: item.accountColor || "#64748b" }} />{item.accountName}</span><span className="text-right tabular-nums text-slate-500">{currency.format(Number(item.previousBalance))}</span><strong className={`text-right tabular-nums ${Number(item.currentBalance) < 0 ? "text-red-600" : "text-slate-900"}`}>{currency.format(Number(item.currentBalance))}</strong><strong className={`text-right tabular-nums ${change < 0 ? "text-red-600" : "text-emerald-600"}`}>{change >= 0 ? "+" : ""}{currency.format(change)}</strong><div className="flex justify-end gap-1"><button type="button" onClick={() => openEdit(item)} className="flex h-7 w-7 items-center justify-center rounded-md text-slate-500 hover:bg-amber-50 hover:text-amber-700"><PencilSquareIcon className="h-4 w-4" /></button><button type="button" onClick={() => setDeleting(item)} className="flex h-7 w-7 items-center justify-center rounded-md text-red-500 hover:bg-red-50"><TrashIcon className="h-4 w-4" /></button></div></div>;
        })}</div> : <p className="px-5 py-6 text-center text-sm text-slate-400">Nessun estratto nel periodo selezionato</p>}
      </div>

      {deleting && <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/40 p-6"><div className="w-full max-w-md rounded-lg border border-slate-200 bg-white p-8"><h2 className="text-xl font-semibold text-slate-900">Eliminare l'estratto conto?</h2><p className="mt-3 text-sm text-slate-600">Verrà eliminato {periodLabel(deleting.period)} per <strong>{deleting.accountName}</strong>.</p><div className="mt-8 flex justify-end gap-3"><button type="button" onClick={() => setDeleting(null)} className="rounded-md border border-slate-300 px-5 py-3">Annulla</button><button type="button" onClick={confirmDelete} disabled={saving} className="rounded-md bg-red-600 px-5 py-3 font-semibold text-white disabled:opacity-60">Elimina</button></div></div></div>}
    </div>
  );
}

function FilterSelect({ value, onChange, children, width }) {
  return <div className="relative"><select value={value} onChange={(event) => onChange(event.target.value)} className={`h-9 appearance-none rounded-md border border-slate-300 bg-white pl-2.5 pr-7 text-xs outline-none focus:border-amber-500 ${width}`}>{children}</select><ChevronDownIcon className="pointer-events-none absolute right-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" /></div>;
}

function FormField({ label, children }) {
  return <label className="text-xs font-medium text-slate-600">{label}<span className="mt-1 block">{children}</span></label>;
}

function Stat({ label, value, icon: Icon, danger = false }) {
  return <div role={danger ? "alert" : undefined} className={`rounded-lg border px-4 py-3 ${danger ? "border-red-300 bg-red-50" : "border-slate-200 bg-white"}`}><div className="flex justify-between"><span className={`text-[10px] font-medium uppercase tracking-wide ${danger ? "text-red-600" : "text-slate-400"}`}>{label}</span><Icon className={`h-4 w-4 ${danger ? "text-red-600" : "text-amber-600"}`} /></div><strong className={`mt-1.5 block text-xl ${danger ? "text-red-700" : "text-slate-900"}`}>{value}</strong></div>;
}

function TrendChart({ data }) {
  if (data.length === 0) return null;
  const values = data.map((item) => item.value);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  const points = data.map((item, index) => `${data.length === 1 ? 50 : (index / (data.length - 1)) * 100},${45 - ((item.value - min) / range) * 35}`).join(" ");
  return <div className="mt-4 rounded-lg border border-slate-200 bg-white px-4 py-3"><div className="flex items-center justify-between"><h2 className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">Andamento patrimonio</h2><span className="text-[10px] text-slate-400">Ultimi {data.length} mesi</span></div><svg viewBox="0 0 100 50" className="mt-1 h-24 w-full" preserveAspectRatio="none" aria-label="Grafico andamento patrimonio"><line x1="0" y1="45" x2="100" y2="45" stroke="#e2e8f0" strokeWidth="0.5" /><polyline points={points} fill="none" stroke="#f59e0b" strokeWidth="1.5" vectorEffect="non-scaling-stroke" /></svg><div className="flex justify-between text-[10px] text-slate-400"><span>{periodLabel(data[0].period)}</span><span>{periodLabel(data[data.length - 1].period)}</span></div></div>;
}
