import { Menu } from "@headlessui/react";
import {
  ArrowRightStartOnRectangleIcon,
  ChevronDownIcon,
  ShieldCheckIcon,
} from "@heroicons/react/24/outline";
import { useNavigate } from "react-router-dom";

export default function UserMenu() {
  const navigate = useNavigate();

  function handleLogout() {
    localStorage.removeItem("token");
    navigate("/", { replace: true });
  }

  return (
    <Menu as="div" className="relative">
      <Menu.Button className="flex h-8 items-center gap-2 rounded-lg border border-slate-200 bg-white px-2.5 text-[12px] font-medium tracking-wide text-slate-700 transition-colors duration-150 hover:border-amber-300 hover:bg-amber-50 hover:text-slate-900">
        <span className="flex h-5 w-5 items-center justify-center rounded-full bg-neutral-800 text-[9px] font-medium text-white">
          M
        </span>
        <span>MANFREDI D.</span>
        <ChevronDownIcon className="h-3.5 w-3.5 text-slate-400" />
      </Menu.Button>

      <Menu.Items className="absolute left-1/2 z-50 mt-1.5 w-48 -translate-x-1/2 overflow-hidden rounded-xl border border-slate-200 bg-white py-1 focus:outline-none">
        <Menu.Item>
          {({ focus }) => (
            <button
              type="button"
              onClick={() => navigate("/security")}
              className={`flex w-full items-center gap-2.5 px-3.5 py-2 text-left text-[13px] font-normal transition-colors duration-150 ${focus ? "bg-amber-50" : ""}`}
            >
              <ShieldCheckIcon className="h-[18px] w-[18px] text-slate-500" />
              <span className="text-slate-700">Sicurezza</span>
            </button>
          )}
        </Menu.Item>

        <div className="mx-3 border-t border-slate-200" />

        <Menu.Item>
          {({ focus }) => (
            <button
              type="button"
              onClick={handleLogout}
              className={`flex w-full items-center gap-2.5 px-3.5 py-2 text-left text-[13px] font-normal text-red-600 transition-colors duration-150 ${focus ? "bg-red-50" : ""}`}
            >
              <ArrowRightStartOnRectangleIcon className="h-[18px] w-[18px]" />
              <span>Logout</span>
            </button>
          )}
        </Menu.Item>
      </Menu.Items>
    </Menu>
  );
}
