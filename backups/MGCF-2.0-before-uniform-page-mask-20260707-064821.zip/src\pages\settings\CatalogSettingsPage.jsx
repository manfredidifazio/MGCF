import { PlusIcon } from "@heroicons/react/24/outline";

import DeleteManagedItemDialog from "../../components/catalog/DeleteManagedItemDialog";
import ManagedItemForm from "../../components/catalog/ManagedItemForm";
import ManagedItemsList from "../../components/catalog/ManagedItemsList";
import { catalogConfigs } from "../../components/catalog/catalogConfig";
import useManagedItems from "../../components/catalog/useManagedItems";

export default function CatalogSettingsPage({ type }) {
  const config = catalogConfigs[type];
  const state = useManagedItems(type);
  const Icon = config.icon;

  return (
    <div className="mx-auto max-w-6xl">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-3">
            <Icon className="h-8 w-8 text-amber-500" />
            <h1 className="text-2xl font-semibold text-slate-900">Gestisci {config.plural.toLocaleLowerCase("it")}</h1>
          </div>
          <p className="mt-2 text-slate-500">{config.description}</p>
        </div>
        <button type="button" onClick={state.openNewItem} className="flex items-center justify-center gap-2 rounded-md bg-amber-500 px-6 py-3 font-semibold text-white transition-colors hover:bg-amber-600">
          <PlusIcon className="h-5 w-5" />
          {config.newLabel}
        </button>
      </div>

      {state.message.text && (
        <p className={`mt-6 rounded-md px-4 py-3 text-sm font-medium ${state.message.error ? "bg-red-50 text-red-700" : "bg-emerald-50 text-emerald-700"}`}>{state.message.text}</p>
      )}

      {state.formOpen && (
        <ManagedItemForm
          key={state.editingItem?.id ?? "new"}
          config={config}
          item={state.editingItem}
          saving={state.saving}
          onSave={state.saveItem}
          onCancel={() => state.setFormOpen(false)}
        />
      )}

      {state.loading ? (
        <p className="mt-8 text-sm text-slate-500">Caricamento...</p>
      ) : (
        <ManagedItemsList config={config} items={state.items} onDelete={state.setDeletingItem} onEdit={state.openEditItem} onStatusChange={state.changeStatus} />
      )}

      <DeleteManagedItemDialog config={config} item={state.deletingItem} deleting={state.saving} onCancel={() => state.setDeletingItem(null)} onConfirm={state.confirmDelete} />
    </div>
  );
}
