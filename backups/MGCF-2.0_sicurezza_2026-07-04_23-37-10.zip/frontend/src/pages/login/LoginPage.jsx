import LoginBackground from "../../components/layout/LoginBackground";
import LoginCard from "../../components/cards/LoginCard";
import LoginHeader from "../../components/layout/LoginHeader";
import LoginForm from "../../components/forms/LoginForm";

export default function LoginPage() {
  return (
    <LoginBackground>
      <div className="flex w-full items-center justify-center">
        <LoginCard>
          <LoginHeader />
          <LoginForm />
        </LoginCard>
      </div>
    </LoginBackground>
  );
}