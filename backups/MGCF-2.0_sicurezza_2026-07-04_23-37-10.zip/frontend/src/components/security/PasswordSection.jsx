export default function PasswordSection() {
  return (
    <section className="mt-10 rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
      <h2 className="text-xl font-semibold text-slate-900">
        Cambio parola d'ordine
      </h2>

      <div className="mt-8 grid grid-cols-1 gap-6">
        <div>
          <label className="mb-2 block text-sm font-medium text-slate-700">
            Parola d'ordine attuale
          </label>
          <input
            type="password"
            className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-amber-500"
          />
        </div>

        <div>
          <label className="mb-2 block text-sm font-medium text-slate-700">
            Nuova parola d'ordine
          </label>
          <input
            type="password"
            className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-amber-500"
          />
        </div>

        <div>
          <label className="mb-2 block text-sm font-medium text-slate-700">
            Conferma nuova parola d'ordine
          </label>
          <input
            type="password"
            className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-amber-500"
          />
        </div>
      </div>

      <button className="mt-8 rounded-xl bg-amber-500 px-6 py-3 font-semibold text-white transition hover:bg-amber-600">
        Aggiorna parola d'ordine
      </button>
    </section>
  );
}
