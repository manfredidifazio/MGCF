import Logo from "../ui/Logo";

export default function LoginHeader() {
  return (
    <header className="mb-10">
      <div className="flex justify-center">
        <Logo />
      </div>

      <h1 className="mt-10 text-center text-4xl font-semibold tracking-tight text-slate-900">
        Benvenuto Manfredi
      </h1>

      <p className="mt-4 text-center text-slate-500">
        Inserisci la parola d'ordine per accedere al gestionale.
      </p>
    </header>
  );
}