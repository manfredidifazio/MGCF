import { Router } from "express";

import {
  getSecurity,
  saveSecurity,
} from "../controllers/securityController.js";

const router = Router();

/*
=========================================
GET SICUREZZA
=========================================
*/

router.get("/", getSecurity);

/*
=========================================
SALVA DOMANDE
=========================================
*/

router.put("/", saveSecurity);

export default router;