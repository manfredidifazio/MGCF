import { login as loginService } from "../services/authService.js";

export async function login(req, res) {
  try {
    const { password } = req.body;

    const result = await loginService(password);

    if (!result.success) {
      return res.status(result.status).json({
        success: false,
        message: result.message,
      });
    }

    return res.json({
      success: true,
      token: result.token,
    });
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      success: false,
      message: "Errore durante il login.",
    });
  }
}