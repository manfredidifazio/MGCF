import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import pool from "../database/database.js";

export async function login(password) {
  const result = await pool.query(`
    SELECT password_hash
    FROM settings
    LIMIT 1
  `);

  if (result.rows.length === 0) {
    return {
      success: false,
      status: 500,
      message: "Configurazione sicurezza non trovata.",
    };
  }

  const validPassword = await bcrypt.compare(
    password,
    result.rows[0].password_hash
  );

  if (!validPassword) {
    return {
      success: false,
      status: 401,
      message: "Password errata",
    };
  }

  const token = jwt.sign(
    { user: "admin" },
    "SECRET_KEY_MGCF",
    {
      expiresIn: "1d",
    }
  );

  return {
    success: true,
    token,
  };
}