import pool from "../database/database.js";

/*
=========================================
STATO DOMANDE DI SICUREZZA
=========================================
*/

export async function getSecurityStatus() {
  const result = await pool.query(`
    SELECT
      middle_school_answer,
      dog_name_answer
    FROM settings
    LIMIT 1
  `);

  if (result.rows.length === 0) {
    return {
      success: false,
      status: 500,
      message: "Configurazione sicurezza non trovata.",
    };
  }

  const row = result.rows[0];

  return {
    success: true,
    middleSchoolConfigured: !!row.middle_school_answer,
    dogConfigured: !!row.dog_name_answer,
    middleSchoolAnswer: row.middle_school_answer ?? "",
    dogNameAnswer: row.dog_name_answer ?? "",
  };
}

/*
=========================================
AGGIORNA DOMANDE DI SICUREZZA
=========================================
*/

export async function updateSecurityAnswers(
  middleSchoolAnswer,
  dogNameAnswer
) {
  await pool.query(
    `
    UPDATE settings
    SET
      middle_school_answer = $1,
      dog_name_answer = $2,
      updated_at = CURRENT_TIMESTAMP
    WHERE id = 1
    `,
    [middleSchoolAnswer, dogNameAnswer]
  );

  return {
    success: true,
  };
}