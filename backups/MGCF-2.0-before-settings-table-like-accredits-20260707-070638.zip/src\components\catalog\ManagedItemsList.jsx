import {
  ArchiveBoxArrowDownIcon,
  ArrowPathIcon,
  PencilSquareIcon,
  TrashIcon,
} from "@heroicons/react/24/outline";

export default function ManagedItemsList({ config, items, onDelete, onEdit, onStatusChange }) {
  const Icon = config.icon;

  if (items.length === 0) {
    return (
      <div className="mt-3 rounded-lg border border-dashed border-slate-300 bg-white p-8 text-center">
        <Icon className="mx-auto h-10 w-10 text-slate-300" />
        <p className="mt-3 font-medium text-slate-700">{config.emptyText}</p>
        <p className="mt-1 text-sm text-slate-500">Aggiungi il primo elemento per mostrarlo nella sidebar.</p>
      </div>
    );
  }

  return (
    <div className="mt-3 overflow-hidden rounded-lg border border-slate-200 bg-white">
      <div className="border-b border-slate-200 px-5 py-3">
        <h2 className="text-base font-semibold text-slate-900">{config.registeredLabel}</h2>
        <p className="mt-1 text-sm text-slate-500">Gli elementi archiviati non vengono mostrati nella sidebar.</p>
      </div>

      <div className="hidden grid-cols-[36px_minmax(160px,1fr)_minmax(220px,1.6fr)_90px_minmax(180px,1fr)_96px] items-center gap-3 border-b border-slate-200 bg-slate-50 px-5 py-2 text-[10px] font-semibold uppercase tracking-wide text-slate-400 lg:grid">
        <span />
        <span>Nome</span>
        <span>Dettagli</span>
        <span>Stato</span>
        <span>Note</span>
        <span className="text-right">Azioni</span>
      </div>

      <div className="divide-y divide-slate-100">
        {items.map((item) => (
          <article
            key={item.id}
            className={`grid grid-cols-1 gap-3 px-5 py-3 lg:grid-cols-[36px_minmax(160px,1fr)_minmax(220px,1.6fr)_90px_minmax(180px,1fr)_96px] lg:items-center ${item.active ? "" : "bg-slate-50 opacity-75"}`}
          >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-amber-50">
              <Icon className="h-5 w-5 text-amber-700" />
            </div>

            <h3 className="min-w-0 truncate text-sm font-semibold uppercase text-slate-900">{item.name}</h3>
            <span className="min-w-0 truncate text-sm text-slate-500">{config.summary(item) || "Nessun dettaglio aggiuntivo"}</span>
            <span className={`w-max rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${item.active ? "bg-emerald-50 text-emerald-700" : "bg-slate-200 text-slate-600"}`}>
              {item.active ? "Attivo" : "Archiviato"}
            </span>
            <span className="min-w-0 truncate text-sm text-slate-400">{item.notes || item.description || "—"}</span>

            <div className="flex shrink-0 items-center gap-1 lg:justify-end">
              <button type="button" onClick={() => onEdit(item)} aria-label={`Modifica ${item.name}`} title="Modifica" className="flex h-8 w-8 items-center justify-center rounded-md text-slate-500 transition-colors hover:bg-amber-50 hover:text-amber-700">
                <PencilSquareIcon className="h-[18px] w-[18px]" />
              </button>
              <button type="button" onClick={() => onStatusChange(item)} aria-label={`${item.active ? "Archivia" : "Ripristina"} ${item.name}`} title={item.active ? "Archivia" : "Ripristina"} className="flex h-8 w-8 items-center justify-center rounded-md text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-800">
                {item.active ? <ArchiveBoxArrowDownIcon className="h-[18px] w-[18px]" /> : <ArrowPathIcon className="h-[18px] w-[18px]" />}
              </button>
              <button type="button" onClick={() => onDelete(item)} aria-label={`Elimina ${item.name}`} title="Elimina" className="flex h-8 w-8 items-center justify-center rounded-md text-red-500 transition-colors hover:bg-red-50 hover:text-red-700">
                <TrashIcon className="h-[18px] w-[18px]" />
              </button>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
