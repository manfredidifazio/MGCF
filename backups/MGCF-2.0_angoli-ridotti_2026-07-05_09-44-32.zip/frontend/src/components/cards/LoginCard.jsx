export default function LoginCard({ children }) {
  return (
    <section
      className="
        w-full
        max-w-[480px]
        rounded-xl
        border
        border-white/70
        bg-white/85
        p-12
        shadow-[0_25px_80px_rgba(15,23,42,.12)]
        backdrop-blur-xl
      "
    >
      {children}
    </section>
  );
}
