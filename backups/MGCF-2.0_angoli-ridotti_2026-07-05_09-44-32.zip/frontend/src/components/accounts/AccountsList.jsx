import {
  ArchiveBoxArrowDownIcon,
  ArrowPathIcon,
  BuildingLibraryIcon,
  PencilSquareIcon,
  TrashIcon,
} from "@heroicons/react/24/outline";

export default function AccountsList({ accounts, onDelete, onEdit, onStatusChange }) {
  if (accounts.length === 0) {
    return (
      <div className="mt-8 rounded-xl border border-dashed border-slate-300 bg-white p-12 text-center">
        <BuildingLibraryIcon className="mx-auto h-12 w-12 text-slate-300" />
        <p className="mt-4 font-medium text-slate-700">Nessun conto registrato</p>
        <p className="mt-1 text-sm text-slate-500">
          Crea il primo conto per iniziare a registrare gli accrediti.
        </p>
      </div>
    );
  }

  return (
    <div className="mt-8 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
      <div className="border-b border-slate-200 px-8 py-5">
        <h2 className="text-lg font-semibold text-slate-900">Conti registrati</h2>
        <p className="mt-1 text-sm text-slate-500">
          I conti archiviati restano disponibili nello storico contabile.
        </p>
      </div>

      <div className="divide-y divide-slate-100">
        {accounts.map((account) => (
          <article
            key={account.id}
            className={`flex flex-col gap-4 px-8 py-5 lg:flex-row lg:items-center ${account.active ? "" : "bg-slate-50 opacity-75"}`}
          >
            <div
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${account.color || "#f59e0b"}20` }}
            >
              <BuildingLibraryIcon
                className="h-6 w-6"
                style={{ color: account.color || "#f59e0b" }}
              />
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-3">
                <h3 className="font-semibold text-slate-900">{account.name}</h3>
                <span
                  className={`rounded-full px-3 py-1 text-xs font-semibold ${account.active ? "bg-emerald-50 text-emerald-700" : "bg-slate-200 text-slate-600"}`}
                >
                  {account.active ? "Attivo" : "Archiviato"}
                </span>
              </div>
              <p className="mt-1 text-sm text-slate-500">
                {[account.bank, account.iban].filter(Boolean).join(" · ") || "Nessun dettaglio aggiuntivo"}
              </p>
              {account.description && (
                <p className="mt-1 truncate text-sm text-slate-400">
                  {account.description}
                </p>
              )}
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => onEdit(account)}
                className="flex items-center gap-2 rounded-lg border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
              >
                <PencilSquareIcon className="h-4 w-4" />
                Modifica
              </button>
              <button
                type="button"
                onClick={() => onStatusChange(account)}
                className="flex items-center gap-2 rounded-lg border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
              >
                {account.active ? (
                  <ArchiveBoxArrowDownIcon className="h-4 w-4" />
                ) : (
                  <ArrowPathIcon className="h-4 w-4" />
                )}
                {account.active ? "Archivia" : "Ripristina"}
              </button>
              <button
                type="button"
                onClick={() => onDelete(account)}
                className="flex items-center gap-2 rounded-lg border border-red-200 px-4 py-2 text-sm font-semibold text-red-600 transition hover:bg-red-50"
              >
                <TrashIcon className="h-4 w-4" />
                Elimina
              </button>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
