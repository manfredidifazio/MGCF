import { BellIcon } from "@heroicons/react/24/outline";

import Logo from "../ui/Logo";
import SettingsMenu from "./SettingsMenu";
import UserMenu from "./UserMenu";

export default function Topbar() {
  return (
    <header className="flex h-14 items-center justify-between border-b border-slate-300 bg-white px-5 shadow-sm">
      <Logo compact />

      <div className="flex items-center gap-2">
        <button
          type="button"
          aria-label="Notifiche"
          className="relative flex h-9 w-9 items-center justify-center rounded-lg border border-amber-300 bg-amber-50 text-amber-700 transition-all duration-200 hover:-translate-y-0.5 hover:border-amber-400 hover:bg-amber-100 hover:shadow-md active:translate-y-0"
        >
          <BellIcon className="h-5 w-5" />
          <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-amber-500 text-[9px] font-bold text-white ring-2 ring-white">
            3
          </span>
        </button>

        <SettingsMenu />
        <UserMenu />
      </div>
    </header>
  );
}
