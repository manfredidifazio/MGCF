import { Menu } from "@headlessui/react";
import {
  ArrowRightStartOnRectangleIcon,
  ChevronDownIcon,
  ShieldCheckIcon,
} from "@heroicons/react/24/outline";
import { useNavigate } from "react-router-dom";

export default function UserMenu() {
  const navigate = useNavigate();

  function handleLogout() {
    localStorage.removeItem("token");
    navigate("/", { replace: true });
  }

  return (
    <Menu as="div" className="relative">
      <Menu.Button className="flex h-9 items-center gap-2 rounded-lg border border-slate-300 bg-slate-100 px-2.5 text-sm text-slate-900 transition-all duration-200 hover:-translate-y-0.5 hover:border-slate-400 hover:bg-white hover:shadow-md active:translate-y-0">
        <span className="flex h-6 w-6 items-center justify-center rounded-full bg-slate-900 text-[11px] font-bold text-white">
          M
        </span>
        <span className="font-semibold">MANFREDI D.</span>
        <ChevronDownIcon className="h-4 w-4 text-slate-500" />
      </Menu.Button>

      <Menu.Items className="absolute left-1/2 z-50 mt-1.5 w-48 -translate-x-1/2 overflow-hidden rounded-xl border border-slate-300 bg-white py-1 shadow-xl focus:outline-none">
        <Menu.Item>
          {({ focus }) => (
            <button
              type="button"
              onClick={() => navigate("/security")}
              className={`flex w-full items-center gap-2.5 px-3.5 py-2 text-left text-sm transition-colors duration-150 ${focus ? "bg-slate-200" : ""}`}
            >
              <ShieldCheckIcon className="h-5 w-5 text-slate-600" />
              <span className="font-semibold text-slate-800">Sicurezza</span>
            </button>
          )}
        </Menu.Item>

        <div className="mx-3 border-t border-slate-200" />

        <Menu.Item>
          {({ focus }) => (
            <button
              type="button"
              onClick={handleLogout}
              className={`flex w-full items-center gap-2.5 px-3.5 py-2 text-left text-sm text-red-600 transition-colors duration-150 ${focus ? "bg-red-100" : ""}`}
            >
              <ArrowRightStartOnRectangleIcon className="h-5 w-5" />
              <span className="font-semibold">Logout</span>
            </button>
          )}
        </Menu.Item>
      </Menu.Items>
    </Menu>
  );
}
