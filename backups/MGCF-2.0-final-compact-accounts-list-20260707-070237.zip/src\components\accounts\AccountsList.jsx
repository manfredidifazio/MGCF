import {
  ArchiveBoxArrowDownIcon,
  ArrowPathIcon,
  BuildingLibraryIcon,
  PencilSquareIcon,
  TrashIcon,
} from "@heroicons/react/24/outline";

export default function AccountsList({ accounts, onDelete, onEdit, onStatusChange }) {
  if (accounts.length === 0) {
    return (
      <div className="mt-3 rounded-lg border border-dashed border-slate-300 bg-white p-8 text-center">
        <BuildingLibraryIcon className="mx-auto h-10 w-10 text-slate-300" />
        <p className="mt-3 font-medium text-slate-700">Nessun conto registrato</p>
        <p className="mt-1 text-sm text-slate-500">
          Crea il primo conto per iniziare a registrare gli accrediti.
        </p>
      </div>
    );
  }

  return (
    <div className="mt-3 overflow-hidden rounded-lg border border-slate-200 bg-white">
      <div className="border-b border-slate-200 px-5 py-3">
        <h2 className="text-base font-semibold text-slate-900">Conti registrati</h2>
        <p className="mt-1 text-sm text-slate-500">
          I conti archiviati restano disponibili nello storico contabile.
        </p>
      </div>

      <div className="divide-y divide-slate-100">
        {accounts.map((account) => (
          <article
            key={account.id}
            className={`flex flex-col gap-3 px-5 py-3 lg:flex-row lg:items-center ${account.active ? "" : "bg-slate-50 opacity-75"}`}
          >
            <div
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md"
              style={{ backgroundColor: `${account.color || "#f59e0b"}20` }}
            >
              <BuildingLibraryIcon
                className="h-5 w-5"
                style={{ color: account.color || "#f59e0b" }}
              />
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex min-w-0 flex-wrap items-center gap-x-2 gap-y-1 text-sm">
                <h3 className="font-semibold uppercase text-slate-900">{account.name}</h3>
                {account.bank && (
                  <>
                    <span className="text-slate-300">-</span>
                    <span className="text-slate-500">{account.bank}</span>
                  </>
                )}
                {account.iban && (
                  <>
                    <span className="text-slate-300">-</span>
                    <span className="text-slate-500">{account.iban}</span>
                  </>
                )}
                <span
                  className={`rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${account.active ? "bg-emerald-50 text-emerald-700" : "bg-slate-200 text-slate-600"}`}
                >
                  {account.active ? "Attivo" : "Archiviato"}
                </span>
                <span className="text-slate-300">-</span>
                <span className="truncate text-slate-400">
                  {account.description || "Conto non ancora presente"}
                </span>
              </div>
            </div>

            <div className="flex shrink-0 items-center gap-1">
              <button
                type="button"
                onClick={() => onEdit(account)}
                aria-label={`Modifica ${account.name}`}
                title="Modifica"
                className="flex h-8 w-8 items-center justify-center rounded-md text-slate-500 transition-colors hover:bg-amber-50 hover:text-amber-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400"
              >
                <PencilSquareIcon className="h-[18px] w-[18px]" />
              </button>
              <button
                type="button"
                onClick={() => onStatusChange(account)}
                aria-label={`${account.active ? "Archivia" : "Ripristina"} ${account.name}`}
                title={account.active ? "Archivia" : "Ripristina"}
                className="flex h-8 w-8 items-center justify-center rounded-md text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-400"
              >
                {account.active ? (
                  <ArchiveBoxArrowDownIcon className="h-[18px] w-[18px]" />
                ) : (
                  <ArrowPathIcon className="h-[18px] w-[18px]" />
                )}
              </button>
              <button
                type="button"
                onClick={() => onDelete(account)}
                aria-label={`Elimina ${account.name}`}
                title="Elimina"
                className="flex h-8 w-8 items-center justify-center rounded-md text-red-500 transition-colors hover:bg-red-50 hover:text-red-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-400"
              >
                <TrashIcon className="h-[18px] w-[18px]" />
              </button>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
