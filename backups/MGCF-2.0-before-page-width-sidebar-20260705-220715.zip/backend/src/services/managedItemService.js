import pool from "../database/database.js";

const fields = `
  id,
  type,
  name,
  details,
  active,
  created_at AS "createdAt",
  updated_at AS "updatedAt"
`;

export async function ensureManagedItemsTable() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS managed_items (
      id SERIAL PRIMARY KEY,
      type VARCHAR(20) NOT NULL CHECK (type IN ('tax', 'property', 'vehicle')),
      name VARCHAR(160) NOT NULL,
      details JSONB NOT NULL DEFAULT '{}'::jsonb,
      active BOOLEAN NOT NULL DEFAULT TRUE,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await pool.query(`
    CREATE INDEX IF NOT EXISTS managed_items_type_active_idx
    ON managed_items (type, active, name)
  `);
}

export async function getManagedItems(type) {
  const result = await pool.query(
    `SELECT ${fields} FROM managed_items WHERE type = $1 ORDER BY active DESC, name ASC`,
    [type]
  );
  return result.rows;
}

export async function createManagedItem(item) {
  const result = await pool.query(
    `
      INSERT INTO managed_items (type, name, details)
      VALUES ($1, $2, $3::jsonb)
      RETURNING ${fields}
    `,
    [item.type, item.name, JSON.stringify(item.details)]
  );
  return result.rows[0];
}

export async function updateManagedItem(id, item) {
  const result = await pool.query(
    `
      UPDATE managed_items
      SET name = $1, details = $2::jsonb, updated_at = CURRENT_TIMESTAMP
      WHERE id = $3 AND type = $4
      RETURNING ${fields}
    `,
    [item.name, JSON.stringify(item.details), id, item.type]
  );
  return result.rows[0] ?? null;
}

export async function setManagedItemActive(id, type, active) {
  const result = await pool.query(
    `
      UPDATE managed_items
      SET active = $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2 AND type = $3
      RETURNING ${fields}
    `,
    [active, id, type]
  );
  return result.rows[0] ?? null;
}

export async function deleteManagedItem(id, type) {
  const result = await pool.query(
    "DELETE FROM managed_items WHERE id = $1 AND type = $2 RETURNING id",
    [id, type]
  );
  return result.rows.length > 0;
}
