import { BrowserRouter, Route, Routes } from "react-router-dom";

import MainLayout from "./layouts/MainLayout";
import AccountingPage from "./pages/accounting/AccountingPage";
import AccountingOverviewPage from "./pages/accounting/AccountingOverviewPage";
import ManagedItemDetailPage from "./pages/catalog/ManagedItemDetailPage";
import Dashboard from "./pages/dashboard/Dashboard";
import LoginPage from "./pages/login/LoginPage";
import SecurityPage from "./pages/security/SecurityPage";
import SettingsPage from "./pages/settings/SettingsPage";
import CatalogSettingsPage from "./pages/settings/CatalogSettingsPage";
import AccountsPage from "./pages/settings/accounts/AccountsPage";
import ProtectedRoute from "./routes/ProtectedRoute";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LoginPage />} />

        <Route
          element={
            <ProtectedRoute>
              <MainLayout />
            </ProtectedRoute>
          }
        >
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/security" element={<SecurityPage />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/settings/accounts" element={<AccountsPage />} />
          <Route path="/settings/taxes" element={<CatalogSettingsPage type="tax" />} />
          <Route path="/settings/properties" element={<CatalogSettingsPage type="property" />} />
          <Route path="/settings/vehicles" element={<CatalogSettingsPage type="vehicle" />} />
          <Route path="/taxes/:id" element={<ManagedItemDetailPage type="tax" />} />
          <Route path="/properties/:id" element={<ManagedItemDetailPage type="property" />} />
          <Route path="/vehicles/:id" element={<ManagedItemDetailPage type="vehicle" />} />
          <Route path="/accounting" element={<AccountingOverviewPage />} />
          <Route path="/accounting/accredits" element={<AccountingPage section="accredits" title="Inserisci accredito" />} />
          <Route path="/accounting/statements" element={<AccountingPage section="statements" title="Visualizza estratti conto" />} />
          <Route path="/accounting/balances" element={<AccountingPage section="balances" title="Visualizza saldi conto" />} />
          <Route path="/accounting/reports" element={<AccountingPage section="reports" title="Resoconto contabile" />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
