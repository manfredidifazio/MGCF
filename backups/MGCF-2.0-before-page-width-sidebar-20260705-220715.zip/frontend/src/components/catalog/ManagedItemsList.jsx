import {
  ArchiveBoxArrowDownIcon,
  ArrowPathIcon,
  PencilSquareIcon,
  TrashIcon,
} from "@heroicons/react/24/outline";

export default function ManagedItemsList({ config, items, onDelete, onEdit, onStatusChange }) {
  const Icon = config.icon;

  if (items.length === 0) {
    return (
      <div className="mt-8 rounded-lg border border-dashed border-slate-300 bg-white p-12 text-center">
        <Icon className="mx-auto h-12 w-12 text-slate-300" />
        <p className="mt-4 font-medium text-slate-700">{config.emptyText}</p>
        <p className="mt-1 text-sm text-slate-500">Aggiungi il primo elemento per mostrarlo nella sidebar.</p>
      </div>
    );
  }

  return (
    <div className="mt-8 overflow-hidden rounded-lg border border-slate-200 bg-white">
      <div className="border-b border-slate-200 px-8 py-5">
        <h2 className="text-lg font-semibold text-slate-900">{config.plural} registrati</h2>
        <p className="mt-1 text-sm text-slate-500">Gli elementi archiviati non vengono mostrati nella sidebar.</p>
      </div>

      <div className="divide-y divide-slate-100">
        {items.map((item) => (
          <article
            key={item.id}
            className={`flex flex-col gap-4 px-8 py-5 lg:flex-row lg:items-center ${item.active ? "" : "bg-slate-50 opacity-75"}`}
          >
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-md bg-amber-50">
              <Icon className="h-5 w-5 text-amber-700" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-3">
                <h3 className="font-semibold text-slate-900">{item.name}</h3>
                <span className={`rounded-full px-3 py-1 text-xs font-semibold ${item.active ? "bg-emerald-50 text-emerald-700" : "bg-slate-200 text-slate-600"}`}>
                  {item.active ? "Attivo" : "Archiviato"}
                </span>
              </div>
              <p className="mt-1 text-sm text-slate-500">{config.summary(item) || "Nessun dettaglio aggiuntivo"}</p>
              {item.notes && <p className="mt-1 truncate text-sm text-slate-400">{item.notes}</p>}
            </div>

            <div className="flex items-center gap-1">
              <button type="button" onClick={() => onEdit(item)} aria-label={`Modifica ${item.name}`} title="Modifica" className="flex h-8 w-8 items-center justify-center rounded-md text-slate-500 transition-colors hover:bg-amber-50 hover:text-amber-700">
                <PencilSquareIcon className="h-[18px] w-[18px]" />
              </button>
              <button type="button" onClick={() => onStatusChange(item)} aria-label={`${item.active ? "Archivia" : "Ripristina"} ${item.name}`} title={item.active ? "Archivia" : "Ripristina"} className="flex h-8 w-8 items-center justify-center rounded-md text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-800">
                {item.active ? <ArchiveBoxArrowDownIcon className="h-[18px] w-[18px]" /> : <ArrowPathIcon className="h-[18px] w-[18px]" />}
              </button>
              <button type="button" onClick={() => onDelete(item)} aria-label={`Elimina ${item.name}`} title="Elimina" className="flex h-8 w-8 items-center justify-center rounded-md text-red-500 transition-colors hover:bg-red-50 hover:text-red-700">
                <TrashIcon className="h-[18px] w-[18px]" />
              </button>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
