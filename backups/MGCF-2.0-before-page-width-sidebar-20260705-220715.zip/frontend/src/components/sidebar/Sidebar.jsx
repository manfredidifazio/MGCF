import {
  ChartBarSquareIcon,
  ChevronDownIcon,
  ClipboardDocumentListIcon,
  DocumentArrowDownIcon,
  DocumentTextIcon,
  HomeModernIcon,
  ReceiptPercentIcon,
  TruckIcon,
} from "@heroicons/react/24/outline";
import { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";

import { getManagedItems } from "../../services/managedItemService";

const accountingItems = [
  { label: "Inserisci accredito", path: "/accounting/accredits", icon: DocumentArrowDownIcon },
  { label: "Visualizza estratti conto", path: "/accounting/statements", icon: DocumentTextIcon },
  { label: "Visualizza saldi conto", path: "/accounting/balances", icon: ChartBarSquareIcon },
  { label: "Resoconto contabile", path: "/accounting/reports", icon: ClipboardDocumentListIcon },
];

const dynamicSections = [
  { type: "tax", label: "Tasse", icon: ReceiptPercentIcon, basePath: "/taxes" },
  { type: "property", label: "Immobili", icon: HomeModernIcon, basePath: "/properties" },
  { type: "vehicle", label: "Veicoli", icon: TruckIcon, basePath: "/vehicles" },
];

function SidebarLink({ item }) {
  const Icon = item.icon;
  return (
    <NavLink
      to={item.path}
      className={({ isActive }) => `flex items-center gap-3 rounded-md px-2 py-2 text-[12px] transition-colors ${isActive ? "bg-amber-50 text-amber-900" : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"}`}
    >
      <Icon className="h-[18px] w-[18px] shrink-0 text-slate-500" />
      <span className="truncate">{item.label}</span>
    </NavLink>
  );
}

function SidebarSection({ label, open, onToggle, children }) {
  return (
    <section className="border-b border-slate-200 py-3">
      <button type="button" onClick={onToggle} aria-expanded={open} className="flex w-full items-center justify-between px-2 py-1 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-800">
        <span>{label}</span>
        <ChevronDownIcon className={`h-4 w-4 text-slate-500 transition-transform ${open ? "" : "-rotate-90"}`} />
      </button>
      {open && <div className="mt-1 space-y-0.5">{children}</div>}
    </section>
  );
}

export default function Sidebar() {
  const [openSections, setOpenSections] = useState({ accounting: true, tax: true, property: true, vehicle: true });
  const [items, setItems] = useState({ tax: [], property: [], vehicle: [] });

  useEffect(() => {
    let active = true;

    async function load(type) {
      try {
        const data = await getManagedItems(type);
        if (active) setItems((current) => ({ ...current, [type]: data.filter((item) => item.active) }));
      } catch {
        if (active) setItems((current) => ({ ...current, [type]: [] }));
      }
    }

    dynamicSections.forEach((section) => load(section.type));
    const handleUpdate = (event) => load(event.detail?.type);
    window.addEventListener("mgcf:managed-items-updated", handleUpdate);

    return () => {
      active = false;
      window.removeEventListener("mgcf:managed-items-updated", handleUpdate);
    };
  }, []);

  function toggle(section) {
    setOpenSections((current) => ({ ...current, [section]: !current[section] }));
  }

  return (
    <aside className="sticky top-14 h-[calc(100vh-56px)] w-72 shrink-0 overflow-y-auto border-r border-slate-200 bg-white px-4 pb-5">
      <SidebarSection label="Contabilità" open={openSections.accounting} onToggle={() => toggle("accounting")}>
        {accountingItems.map((item) => <SidebarLink key={item.path} item={item} />)}
      </SidebarSection>

      {dynamicSections.map((section) => {
        const Icon = section.icon;
        return (
          <SidebarSection key={section.type} label={section.label} open={openSections[section.type]} onToggle={() => toggle(section.type)}>
            {items[section.type].length > 0 ? items[section.type].map((item) => (
              <SidebarLink key={item.id} item={{ label: item.name, path: `${section.basePath}/${item.id}`, icon: Icon }} />
            )) : (
              <p className="px-2 py-2 text-[11px] text-slate-400">Nessun elemento attivo</p>
            )}
          </SidebarSection>
        );
      })}
    </aside>
  );
}
