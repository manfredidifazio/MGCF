import { Router } from "express";

import {
  login,
  recoverPassword,
} from "../controllers/authController.js";

const router = Router();

router.post("/login", login);
router.post("/recover-password", recoverPassword);

export default router;
