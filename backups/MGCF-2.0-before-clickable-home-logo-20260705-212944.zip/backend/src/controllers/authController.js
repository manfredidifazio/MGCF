import {
  login as loginService,
  recoverPassword as recoverPasswordService,
} from "../services/authService.js";

export async function login(req, res) {
  try {
    const { password } = req.body;
    const result = await loginService(password);

    return res.status(result.status ?? 200).json(result);
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      success: false,
      message: "Errore durante il login.",
    });
  }
}

export async function recoverPassword(req, res) {
  try {
    const {
      middleSchoolAnswer,
      dogNameAnswer,
      newPassword,
    } = req.body;

    const values = [middleSchoolAnswer, dogNameAnswer, newPassword];
    const invalidValues = values.some(
      (value) => typeof value !== "string" || !value.trim()
    );

    if (invalidValues) {
      return res.status(400).json({
        success: false,
        message: "Compila tutti i campi richiesti.",
      });
    }

    const result = await recoverPasswordService(
      middleSchoolAnswer,
      dogNameAnswer,
      newPassword
    );

    return res.status(result.status ?? 200).json(result);
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      success: false,
      message: "Errore durante il ripristino della parola d'ordine.",
    });
  }
}
