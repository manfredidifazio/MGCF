import dotenv from "dotenv";
import app from "./app.js";
import pool from "./database/database.js";

dotenv.config();

const PORT = process.env.PORT || 5000;

async function startServer() {
  try {
    await pool.query("SELECT NOW()");

    console.log("✅ PostgreSQL connesso");

    app.listen(PORT, () => {
      console.log(`🚀 Server avviato sulla porta ${PORT}`);
    });
  } catch (error) {
    console.error("❌ Errore connessione database");
    console.error(error.message);
    process.exit(1);
  }
}

startServer();