import pool from "../database/database.js";

const accountFields = `
  id,
  name,
  bank,
  iban,
  description,
  color,
  active,
  created_at AS "createdAt",
  updated_at AS "updatedAt"
`;

export async function getAccounts() {
  const result = await pool.query(`
    SELECT ${accountFields}
    FROM accounts
    ORDER BY active DESC, name ASC
  `);

  return result.rows;
}

async function accountNameExists(name, excludedId = null) {
  const result = await pool.query(
    `
      SELECT 1
      FROM accounts
      WHERE LOWER(name) = LOWER($1)
        AND ($2::integer IS NULL OR id <> $2)
      LIMIT 1
    `,
    [name, excludedId]
  );

  return result.rows.length > 0;
}

export async function createAccount(account) {
  if (await accountNameExists(account.name)) {
    return {
      success: false,
      status: 409,
      message: "Esiste già un conto con questo nome.",
    };
  }

  const result = await pool.query(
    `
      INSERT INTO accounts (name, bank, iban, description, color)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING ${accountFields}
    `,
    [account.name, account.bank, account.iban, account.description, account.color]
  );

  return { success: true, account: result.rows[0] };
}

export async function updateAccount(id, account) {
  if (await accountNameExists(account.name, id)) {
    return {
      success: false,
      status: 409,
      message: "Esiste già un conto con questo nome.",
    };
  }

  const result = await pool.query(
    `
      UPDATE accounts
      SET name = $1,
          bank = $2,
          iban = $3,
          description = $4,
          color = $5,
          updated_at = CURRENT_TIMESTAMP
      WHERE id = $6
      RETURNING ${accountFields}
    `,
    [account.name, account.bank, account.iban, account.description, account.color, id]
  );

  if (result.rows.length === 0) {
    return { success: false, status: 404, message: "Conto non trovato." };
  }

  return { success: true, account: result.rows[0] };
}

export async function setAccountActive(id, active) {
  const result = await pool.query(
    `
      UPDATE accounts
      SET active = $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING ${accountFields}
    `,
    [active, id]
  );

  if (result.rows.length === 0) {
    return { success: false, status: 404, message: "Conto non trovato." };
  }

  return { success: true, account: result.rows[0] };
}

export async function deleteAccount(id) {
  const result = await pool.query(
    `
      DELETE FROM accounts
      WHERE id = $1
        AND NOT EXISTS (
          SELECT 1 FROM accredits WHERE account_id = $1
        )
      RETURNING id
    `,
    [id]
  );

  if (result.rows.length > 0) {
    return { success: true };
  }

  const existing = await pool.query(
    "SELECT 1 FROM accounts WHERE id = $1 LIMIT 1",
    [id]
  );

  if (existing.rows.length === 0) {
    return { success: false, status: 404, message: "Conto non trovato." };
  }

  return {
    success: false,
    status: 409,
    message: "Il conto contiene movimenti e non può essere eliminato. Puoi archiviarlo.",
  };
}
