import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

import { JWT_SECRET } from "../config/auth.js";
import pool from "../database/database.js";

export async function login(password) {
  const result = await pool.query(`
    SELECT password_hash
    FROM settings
    LIMIT 1
  `);

  if (result.rows.length === 0) {
    return {
      success: false,
      status: 500,
      message: "Configurazione sicurezza non trovata.",
    };
  }

  const validPassword = await bcrypt.compare(
    password,
    result.rows[0].password_hash
  );

  if (!validPassword) {
    return {
      success: false,
      status: 401,
      message: "Parola d'ordine errata.",
    };
  }

  const token = jwt.sign({ user: "admin" }, JWT_SECRET, {
    expiresIn: "1d",
  });

  return { success: true, token };
}

export async function recoverPassword(
  middleSchoolAnswer,
  dogNameAnswer,
  newPassword
) {
  const result = await pool.query(`
    SELECT middle_school_answer, dog_name_answer
    FROM settings
    WHERE id = 1
  `);

  if (result.rows.length === 0) {
    return {
      success: false,
      status: 500,
      message: "Configurazione sicurezza non trovata.",
    };
  }

  const row = result.rows[0];

  if (!row.middle_school_answer || !row.dog_name_answer) {
    return {
      success: false,
      status: 400,
      message: "Le domande di sicurezza non sono ancora configurate.",
    };
  }

  const normalize = (value) => value.trim().toLocaleLowerCase("it-IT");
  const answersMatch =
    normalize(middleSchoolAnswer) === normalize(row.middle_school_answer) &&
    normalize(dogNameAnswer) === normalize(row.dog_name_answer);

  if (!answersMatch) {
    return {
      success: false,
      status: 401,
      message: "Le risposte di sicurezza non sono corrette.",
    };
  }

  const passwordHash = await bcrypt.hash(newPassword, 10);

  await pool.query(
    `
      UPDATE settings
      SET password_hash = $1, updated_at = CURRENT_TIMESTAMP
      WHERE id = 1
    `,
    [passwordHash]
  );

  return {
    success: true,
    message: "Parola d'ordine ripristinata correttamente.",
  };
}
