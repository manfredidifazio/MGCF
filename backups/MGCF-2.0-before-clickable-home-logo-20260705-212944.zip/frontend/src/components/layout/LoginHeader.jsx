import Logo from "../ui/Logo";

export default function LoginHeader({ recovery = false }) {
  return (
    <header className="mb-10">
      <div className="flex justify-center">
        <Logo />
      </div>

      {recovery && (
        <h1 className="mt-10 text-center text-4xl font-semibold tracking-tight text-slate-900">
          Ripristina l'accesso
        </h1>
      )}

      <p className={`${recovery ? "mt-4" : "mt-10"} text-center text-slate-500`}>
        {recovery
          ? "Rispondi alle domande di sicurezza e scegli una nuova parola d'ordine."
          : "Inserisci la parola d'ordine per accedere al gestionale."}
      </p>
    </header>
  );
}
