import { useState } from "react";

import { login } from "../../services/authService";
import Button from "../ui/Button";
import Input from "../ui/Input";

export default function LoginForm({ onForgotPassword }) {
  const [password, setPassword] = useState("");

  async function handleSubmit(event) {
    event.preventDefault();

    try {
      const response = await login(password);

      if (response.success) {
        localStorage.setItem("token", response.token);
        window.location.href = "/dashboard";
      }
    } catch (error) {
      console.error(error);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <Input
        label="Parola d'ordine"
        type="password"
        placeholder="••••••••••••"
        value={password}
        onChange={(event) => setPassword(event.target.value)}
      />

      <Button type="submit" fullWidth>
        Accedi
      </Button>

      <button
        type="button"
        onClick={onForgotPassword}
        className="block w-full text-center text-sm font-medium text-slate-500 transition hover:text-amber-600"
      >
        Hai dimenticato la parola d'ordine?
      </button>
    </form>
  );
}
