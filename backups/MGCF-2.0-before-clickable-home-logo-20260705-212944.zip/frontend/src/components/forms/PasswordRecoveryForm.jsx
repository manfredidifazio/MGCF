import { useState } from "react";

import { recoverPassword } from "../../services/authService";
import Button from "../ui/Button";
import Input from "../ui/Input";

const initialFields = {
  middleSchoolAnswer: "",
  dogNameAnswer: "",
  newPassword: "",
  confirmPassword: "",
};

export default function PasswordRecoveryForm({ onBack }) {
  const [fields, setFields] = useState(initialFields);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState({ text: "", error: false });

  function updateField(name, value) {
    setFields((current) => ({ ...current, [name]: value }));
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setMessage({ text: "", error: false });

    const hasEmptyFields = Object.values(fields).some(
      (value) => !value.trim()
    );

    if (hasEmptyFields) {
      setMessage({ text: "Compila tutti i campi richiesti.", error: true });
      return;
    }

    if (fields.newPassword !== fields.confirmPassword) {
      setMessage({
        text: "La nuova parola d'ordine e la conferma non coincidono.",
        error: true,
      });
      return;
    }

    setSaving(true);

    try {
      const data = await recoverPassword(
        fields.middleSchoolAnswer,
        fields.dogNameAnswer,
        fields.newPassword
      );

      setFields(initialFields);
      setMessage({
        text: data.message ?? "Parola d'ordine ripristinata correttamente.",
        error: false,
      });
    } catch (error) {
      setMessage({
        text: error.response?.data?.message ?? "Errore durante il ripristino.",
        error: true,
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Input
        label="Scuola media frequentata"
        value={fields.middleSchoolAnswer}
        onChange={(event) => updateField("middleSchoolAnswer", event.target.value)}
      />

      <Input
        label="Nome del cane"
        value={fields.dogNameAnswer}
        onChange={(event) => updateField("dogNameAnswer", event.target.value)}
      />

      <Input
        label="Nuova parola d'ordine"
        type="password"
        value={fields.newPassword}
        onChange={(event) => updateField("newPassword", event.target.value)}
      />

      <Input
        label="Conferma nuova parola d'ordine"
        type="password"
        value={fields.confirmPassword}
        onChange={(event) => updateField("confirmPassword", event.target.value)}
      />

      {message.text && (
        <p
          aria-live="polite"
          className={`text-center text-sm font-medium ${message.error ? "text-red-600" : "text-emerald-600"}`}
        >
          {message.text}
        </p>
      )}

      <Button type="submit" fullWidth disabled={saving}>
        {saving ? "Ripristino in corso..." : "Ripristina parola d'ordine"}
      </Button>

      <button
        type="button"
        onClick={onBack}
        className="block w-full text-center text-sm font-medium text-slate-500 transition hover:text-amber-600"
      >
        Torna alla schermata di accesso
      </button>
    </form>
  );
}
