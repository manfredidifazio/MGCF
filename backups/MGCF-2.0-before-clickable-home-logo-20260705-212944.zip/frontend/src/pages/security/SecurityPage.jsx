import PasswordSection from "../../components/security/PasswordSection";
import SecurityQuestionsSection from "../../components/security/SecurityQuestionsSection";

export default function SecurityPage() {
  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="text-3xl font-bold text-slate-900">Sicurezza</h1>

      <p className="mt-2 text-slate-500">
        Gestisci la parola d'ordine e le domande di sicurezza del tuo account.
      </p>

      <PasswordSection />
      <SecurityQuestionsSection />
    </div>
  );
}
