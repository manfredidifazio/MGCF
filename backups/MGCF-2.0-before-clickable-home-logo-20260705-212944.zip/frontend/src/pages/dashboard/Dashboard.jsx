export default function Dashboard() {
  return (
    <div className="p-10">
      <h1 className="text-2xl font-bold">
        Dashboard MGCF
      </h1>

      <p className="mt-2 text-slate-600">
        Login avvenuto correttamente
      </p>
    </div>
  );
}