import { useState } from "react";

import LoginCard from "../../components/cards/LoginCard";
import LoginForm from "../../components/forms/LoginForm";
import PasswordRecoveryForm from "../../components/forms/PasswordRecoveryForm";
import LoginBackground from "../../components/layout/LoginBackground";
import LoginHeader from "../../components/layout/LoginHeader";

export default function LoginPage() {
  const [recovery, setRecovery] = useState(false);

  return (
    <LoginBackground>
      <div className="flex w-full items-center justify-center">
        <LoginCard>
          <LoginHeader recovery={recovery} />

          {recovery ? (
            <PasswordRecoveryForm onBack={() => setRecovery(false)} />
          ) : (
            <LoginForm onForgotPassword={() => setRecovery(true)} />
          )}
        </LoginCard>
      </div>
    </LoginBackground>
  );
}
