import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:5000",
});

export async function login(password) {
  const { data } = await api.post("/auth/login", { password });
  return data;
}

export async function recoverPassword(
  middleSchoolAnswer,
  dogNameAnswer,
  newPassword
) {
  const { data } = await api.post("/auth/recover-password", {
    middleSchoolAnswer,
    dogNameAnswer,
    newPassword,
  });

  return data;
}
