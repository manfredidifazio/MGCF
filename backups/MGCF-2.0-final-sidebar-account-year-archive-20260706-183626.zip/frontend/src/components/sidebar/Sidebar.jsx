import {
  ChartBarSquareIcon,
  ChevronDownIcon,
  ClipboardDocumentListIcon,
  DocumentArrowDownIcon,
  DocumentTextIcon,
  HomeModernIcon,
  MinusIcon,
  PlusIcon,
  ReceiptPercentIcon,
  TruckIcon,
} from "@heroicons/react/24/outline";
import { useEffect, useMemo, useState } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";

import { getAccounts } from "../../services/accountService";
import { getAccountStatements } from "../../services/accountStatementService";
import { getAccredits } from "../../services/accreditService";
import { getManagedItems } from "../../services/managedItemService";
import { accountingYears } from "../../utils/accountingPeriods";

const accountingItems = [
  { label: "Visualizza saldi conto", path: "/accounting/balances", icon: ChartBarSquareIcon },
  { label: "Visualizza resoconto contabile", path: "/accounting/reports", icon: ClipboardDocumentListIcon },
];

const dynamicSections = [
  { type: "tax", label: "Tasse", icon: ReceiptPercentIcon, basePath: "/taxes", settingsPath: "/settings/taxes" },
  { type: "property", label: "Immobili", icon: HomeModernIcon, basePath: "/properties", settingsPath: "/settings/properties" },
  { type: "vehicle", label: "Veicoli", icon: TruckIcon, basePath: "/vehicles", settingsPath: "/settings/vehicles" },
];

function normalizedSearch(value) {
  return [...new URLSearchParams(value).entries()]
    .sort(([firstKey, firstValue], [secondKey, secondValue]) => firstKey.localeCompare(secondKey) || firstValue.localeCompare(secondValue))
    .map(([key, item]) => `${key}=${item}`)
    .join("&");
}

function TreeLink({ to, children, className = "" }) {
  const location = useLocation();
  const [pathname, search = ""] = to.split("?");
  const active = location.pathname === pathname && normalizedSearch(location.search) === normalizedSearch(search);

  return <Link to={to} className={`${className} transition-colors hover:text-amber-700 ${active ? "text-amber-700" : "text-slate-600"}`}>{children}</Link>;
}

function SidebarLink({ item }) {
  const Icon = item.icon;
  return (
    <NavLink
      to={item.path}
      className={({ isActive }) => `flex items-center gap-3 rounded-md px-2 py-2 text-[12px] transition-colors ${isActive ? "bg-amber-50 text-amber-900" : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"}`}
    >
      <Icon className="h-[18px] w-[18px] shrink-0 text-slate-500" />
      <span className="truncate">{item.label}</span>
    </NavLink>
  );
}

function ToggleButton({ open, onToggle, label, compact = false }) {
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-expanded={open}
      aria-label={`${open ? "Nascondi" : "Mostra"} ${label}`}
      className={`flex shrink-0 items-center justify-center rounded-md text-slate-500 transition-colors hover:bg-slate-50 hover:text-amber-700 ${compact ? "h-6 w-6" : "h-7 w-7"}`}
    >
      {compact ? (open ? <MinusIcon className="h-3.5 w-3.5" /> : <PlusIcon className="h-3.5 w-3.5" />) : <ChevronDownIcon className={`h-4 w-4 transition-transform ${open ? "" : "-rotate-90"}`} />}
    </button>
  );
}

function SidebarSection({ label, path, open, onToggle, children }) {
  return (
    <section className="border-b border-slate-200 py-3">
      <div className="flex items-center justify-between">
        <NavLink
          to={path}
          className={({ isActive }) => `min-w-0 flex-1 px-2 py-1 text-[11px] font-semibold uppercase tracking-wide transition-colors hover:text-amber-700 ${isActive ? "text-amber-700" : "text-slate-800"}`}
        >
          {label}
        </NavLink>
        <ToggleButton open={open} onToggle={onToggle} label={`menu ${label}`} />
      </div>
      {open && <div className="mt-1 space-y-0.5">{children}</div>}
    </section>
  );
}

function AccountingTreeGroup({ label, path, icon: Icon, open, onToggle, children }) {
  return (
    <div>
      <div className="flex items-center rounded-md hover:bg-slate-50">
        <TreeLink to={path} className="flex min-w-0 flex-1 items-center gap-3 px-2 py-2 text-[12px] font-medium">
          <Icon className="h-[18px] w-[18px] shrink-0 text-slate-500" />
          <span className="truncate">{label}</span>
        </TreeLink>
        <ToggleButton open={open} onToggle={onToggle} label={label} compact />
      </div>
      {open && <div className="ml-5 border-l border-slate-200 pl-2">{children}</div>}
    </div>
  );
}

function AccountBranch({ account, years, type, open, onToggle }) {
  const isAccredits = type === "accredits";
  const rootPath = isAccredits
    ? `/accounting/accredits?account=${account.id}&month=&year=`
    : `/accounting/statements/${account.id}`;
  const prefix = isAccredits ? "Accrediti" : "Estratti";

  return (
    <div>
      <div className="flex items-center rounded-md hover:bg-slate-50">
        <TreeLink to={rootPath} className="flex min-w-0 flex-1 items-center gap-2 py-1.5 pl-1 text-[11px] font-medium">
          <span className="h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: account.color || "#64748b" }} />
          <span className="truncate">{prefix} {account.name}</span>
        </TreeLink>
        <ToggleButton open={open} onToggle={onToggle} label={`${prefix} ${account.name}`} compact />
      </div>
      {open && (
        <div className="ml-3 border-l border-slate-200 py-0.5 pl-3">
          {years.map((year) => {
            const path = isAccredits
              ? `/accounting/accredits?account=${account.id}&month=&year=${year}`
              : `/accounting/statements/${account.id}?year=${year}`;
            return <TreeLink key={year} to={path} className="block rounded px-2 py-1 text-[10px] hover:bg-amber-50">Anno {year}</TreeLink>;
          })}
        </div>
      )}
    </div>
  );
}

export default function Sidebar() {
  const [openSections, setOpenSections] = useState({ accounting: true, tax: true, property: true, vehicle: true });
  const [openTrees, setOpenTrees] = useState({ accredits: true, statements: true });
  const [openAccounts, setOpenAccounts] = useState({});
  const [items, setItems] = useState({ tax: [], property: [], vehicle: [] });
  const [accountingData, setAccountingData] = useState({ accounts: [], accredits: [], statements: [] });

  useEffect(() => {
    let active = true;

    async function load(type) {
      try {
        const data = await getManagedItems(type);
        if (active) setItems((current) => ({ ...current, [type]: data.filter((item) => item.active) }));
      } catch {
        if (active) setItems((current) => ({ ...current, [type]: [] }));
      }
    }

    async function loadAccounting() {
      try {
        const [accounts, accredits, statements] = await Promise.all([getAccounts(), getAccredits(), getAccountStatements()]);
        if (!active) return;
        const activeAccounts = accounts.filter((account) => account.active);
        setAccountingData({ accounts: activeAccounts, accredits, statements });
        if (activeAccounts[0]) {
          setOpenAccounts((current) => Object.keys(current).length ? current : {
            [`accredits-${activeAccounts[0].id}`]: true,
            [`statements-${activeAccounts[0].id}`]: true,
          });
        }
      } catch {
        if (active) setAccountingData({ accounts: [], accredits: [], statements: [] });
      }
    }

    dynamicSections.forEach((section) => load(section.type));
    loadAccounting();
    const handleManagedUpdate = (event) => load(event.detail?.type);
    window.addEventListener("mgcf:managed-items-updated", handleManagedUpdate);
    window.addEventListener("mgcf:accounts-updated", loadAccounting);
    window.addEventListener("mgcf:accredits-updated", loadAccounting);
    window.addEventListener("mgcf:account-statements-updated", loadAccounting);

    return () => {
      active = false;
      window.removeEventListener("mgcf:managed-items-updated", handleManagedUpdate);
      window.removeEventListener("mgcf:accounts-updated", loadAccounting);
      window.removeEventListener("mgcf:accredits-updated", loadAccounting);
      window.removeEventListener("mgcf:account-statements-updated", loadAccounting);
    };
  }, []);

  const availableYears = useMemo(() => {
    return accountingYears(
      accountingData.accredits.map((item) => item.movementDate),
      accountingData.statements.map((item) => item.period),
    );
  }, [accountingData.accredits, accountingData.statements]);

  function toggleSection(section) {
    setOpenSections((current) => ({ ...current, [section]: !current[section] }));
  }

  function toggleTree(tree) {
    setOpenTrees((current) => ({ ...current, [tree]: !current[tree] }));
  }

  function toggleAccount(key) {
    setOpenAccounts((current) => ({ ...current, [key]: !current[key] }));
  }

  return (
    <aside className="sticky top-14 h-[calc(100vh-56px)] w-64 shrink-0 overflow-y-auto border-r border-slate-200 bg-white px-4 pb-5">
      <SidebarSection label="Contabilità" path="/accounting" open={openSections.accounting} onToggle={() => toggleSection("accounting")}>
        <AccountingTreeGroup label="Inserisci accrediti" path="/accounting/accredits" icon={DocumentArrowDownIcon} open={openTrees.accredits} onToggle={() => toggleTree("accredits")}>
          {accountingData.accounts.map((account) => <AccountBranch key={account.id} account={account} years={availableYears} type="accredits" open={Boolean(openAccounts[`accredits-${account.id}`])} onToggle={() => toggleAccount(`accredits-${account.id}`)} />)}
        </AccountingTreeGroup>
        <AccountingTreeGroup label="Gestisci estratti conto" path="/accounting/statements" icon={DocumentTextIcon} open={openTrees.statements} onToggle={() => toggleTree("statements")}>
          {accountingData.accounts.map((account) => <AccountBranch key={account.id} account={account} years={availableYears} type="statements" open={Boolean(openAccounts[`statements-${account.id}`])} onToggle={() => toggleAccount(`statements-${account.id}`)} />)}
        </AccountingTreeGroup>
        {accountingItems.map((item) => <SidebarLink key={item.path} item={item} />)}
      </SidebarSection>

      {dynamicSections.map((section) => {
        const Icon = section.icon;
        return (
          <SidebarSection key={section.type} label={section.label} path={section.settingsPath} open={openSections[section.type]} onToggle={() => toggleSection(section.type)}>
            {items[section.type].length > 0 ? items[section.type].map((item) => (
              <SidebarLink key={item.id} item={{ label: item.name, path: `${section.basePath}/${item.id}`, icon: Icon }} />
            )) : (
              <p className="px-2 py-2 text-[11px] text-slate-400">Nessun elemento attivo</p>
            )}
          </SidebarSection>
        );
      })}
      <div className="mt-3">
        <SidebarLink item={{ label: "Visualizza resoconto fiscale", path: "/fiscal/reports", icon: ReceiptPercentIcon }} />
      </div>
    </aside>
  );
}
