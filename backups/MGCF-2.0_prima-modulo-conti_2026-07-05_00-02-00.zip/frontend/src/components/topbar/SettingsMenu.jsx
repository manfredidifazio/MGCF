import { Menu } from "@headlessui/react";
import { Cog6ToothIcon, ChevronDownIcon } from "@heroicons/react/24/outline";

export default function SettingsMenu() {
  return (
    <Menu as="div" className="relative">

      <Menu.Button className="flex h-11 items-center gap-3 rounded-xl border border-slate-200 bg-white px-5 transition hover:bg-slate-50">

        <Cog6ToothIcon className="h-5 w-5 text-slate-600" />

        <span className="font-semibold">
          IMPOSTAZIONI
        </span>

        <ChevronDownIcon className="h-4 w-4 text-slate-500" />

      </Menu.Button>

      <Menu.Items className="absolute right-0 mt-3 w-56 rounded-2xl border border-slate-200 bg-white py-2 shadow-xl focus:outline-none">

        <Menu.Item>
          {() => (
            <button className="w-full px-5 py-3 text-left hover:bg-slate-100">
              Conti
            </button>
          )}
        </Menu.Item>

        <Menu.Item>
          {() => (
            <button className="w-full px-5 py-3 text-left hover:bg-slate-100">
              Tasse
            </button>
          )}
        </Menu.Item>

        <Menu.Item>
          {() => (
            <button className="w-full px-5 py-3 text-left hover:bg-slate-100">
              Immobili
            </button>
          )}
        </Menu.Item>

        <Menu.Item>
          {() => (
            <button className="w-full px-5 py-3 text-left hover:bg-slate-100">
              Veicoli
            </button>
          )}
        </Menu.Item>

        <Menu.Item>
          {() => (
            <button className="w-full px-5 py-3 text-left hover:bg-slate-100">
              Causali
            </button>
          )}
        </Menu.Item>

      </Menu.Items>

    </Menu>
  );
}