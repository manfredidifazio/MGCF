import { useState } from "react";
import { useNavigate } from "react-router-dom";
import logoMGCF from "../../assets/logo.png";
import {
  BellIcon,
  ChevronDownIcon,
} from "@heroicons/react/24/outline";

export default function Topbar() {
  const navigate = useNavigate();

  const [settingsOpen, setSettingsOpen] = useState(false);
  const [userOpen, setUserOpen] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/", { replace: true });
  };

  const goToSecurity = () => {
    setUserOpen(false);
    navigate("/security");
  };

  return (
    <header className="h-20 bg-white border-b border-slate-200 px-8 flex items-center justify-between">
      {/* LOGO */}
      <div className="flex items-center">
        <img
          src={logoMGCF}
          alt="MGCF"
          className="h-16 w-auto object-contain select-none"
          draggable={false}
        />
      </div>

      {/* DESTRA */}
      <div className="flex items-center gap-4">
        {/* NOTIFICHE */}
        <button className="relative flex h-11 w-11 items-center justify-center rounded-xl border border-slate-200 bg-white hover:bg-slate-50 transition">
          <BellIcon className="h-6 w-6 text-slate-700" />

          <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-amber-500 text-[10px] font-bold text-white">
            3
          </span>
        </button>

        {/* IMPOSTAZIONI */}
        <div className="relative">
          <button
            onClick={() => {
              setSettingsOpen(!settingsOpen);
              setUserOpen(false);
            }}
            className="flex h-11 items-center gap-3 rounded-xl border border-slate-200 bg-white px-5 hover:bg-slate-50 transition"
          >
            <span className="font-semibold">
              IMPOSTAZIONI
            </span>

            <ChevronDownIcon className="h-4 w-4" />
          </button>

          {settingsOpen && (
            <div className="absolute right-0 mt-2 w-56 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xl z-50">
              {[
                "Conti",
                "Tasse",
                "Immobili",
                "Veicoli",
                "Causali",
              ].map((item) => (
                <button
                  key={item}
                  className="w-full px-5 py-3 text-left hover:bg-slate-100 transition"
                >
                  {item}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* UTENTE */}
        <div className="relative">
          <button
            onClick={() => {
              setUserOpen(!userOpen);
              setSettingsOpen(false);
            }}
            className="flex h-11 items-center gap-3 rounded-xl border border-slate-200 bg-white px-4 hover:bg-slate-50 transition"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-900 text-sm font-semibold text-white">
              M
            </div>

            <span className="font-semibold">
              MANFREDI D.
            </span>

            <ChevronDownIcon className="h-4 w-4" />
          </button>

          {userOpen && (
            <div className="absolute right-0 mt-2 w-64 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xl z-50">
              <button
                onClick={goToSecurity}
                className="w-full px-5 py-3 text-left hover:bg-slate-100 transition"
              >
                Sicurezza
              </button>

              <button
                onClick={handleLogout}
                className="w-full px-5 py-3 text-left text-red-600 hover:bg-red-50 transition"
              >
                Logout
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}