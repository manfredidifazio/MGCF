import express from "express";
import cors from "cors";

import authRoutes from "./routes/authRoutes.js";
import securityRoutes from "./routes/securityRoutes.js";

const app = express();

app.use(cors());
app.use(express.json());

app.use("/auth", authRoutes);
app.use("/security", securityRoutes);

app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "MGCF API attiva",
  });
});

export default app;