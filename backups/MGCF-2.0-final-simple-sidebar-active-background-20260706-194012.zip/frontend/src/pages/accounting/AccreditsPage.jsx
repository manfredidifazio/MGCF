import {
  ArrowLeftIcon,
  ArrowTrendingUpIcon,
  BanknotesIcon,
  CalculatorIcon,
  ChevronDownIcon,
  ChevronRightIcon,
  ExclamationTriangleIcon,
  PencilSquareIcon,
  PlusIcon,
  TrashIcon,
} from "@heroicons/react/24/outline";
import { useEffect, useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";

import { getAccounts } from "../../services/accountService";
import { createAccredit, deleteAccredit, getAccredits, updateAccredit } from "../../services/accreditService";
import { getManagedItems } from "../../services/managedItemService";

const currency = new Intl.NumberFormat("it-IT", { style: "currency", currency: "EUR" });
const dateFormatter = new Intl.DateTimeFormat("it-IT");
const months = [
  ["01", "Gennaio"], ["02", "Febbraio"], ["03", "Marzo"], ["04", "Aprile"],
  ["05", "Maggio"], ["06", "Giugno"], ["07", "Luglio"], ["08", "Agosto"],
  ["09", "Settembre"], ["10", "Ottobre"], ["11", "Novembre"], ["12", "Dicembre"],
];

function localDate() {
  const date = new Date();
  const offset = date.getTimezoneOffset() * 60000;
  return new Date(date.getTime() - offset).toISOString().slice(0, 10);
}

function emptyForm() {
  return { movementDate: localDate(), amount: "", accountId: "", causeId: "", notes: "" };
}

function currentMonthFilters() {
  const today = localDate();
  return { accountId: "", month: today.slice(5, 7), year: today.slice(0, 4) };
}

function errorMessage(error, fallback) {
  return error.response?.data?.message ?? fallback;
}

function monthKey(date) {
  return String(date).slice(0, 7);
}

function shiftedMonthKey(year, month, offset) {
  const date = new Date(Number(year), Number(month) - 1 + offset, 1);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

function monthKeyLabel(key) {
  const [year, month] = key.split("-");
  const name = months.find(([value]) => value === month)?.[1] ?? month;
  return `${name.toLocaleLowerCase("it")} ${year}`;
}

function periodStatisticLabels(filters) {
  const monthName = months.find(([value]) => value === filters.month)?.[1].toLocaleLowerCase("it");

  if (monthName && filters.year) {
    const period = `${monthName} ${filters.year}`;
    return {
      amount: `Importo di ${period}`,
      count: `Accrediti di ${period}`,
      average: `Media di ${period}`,
      variation: `Variazione di ${period}`,
    };
  }

  if (filters.year) {
    return {
      amount: `Importo del ${filters.year}`,
      count: `Accrediti del ${filters.year}`,
      average: `Media del ${filters.year}`,
      variation: `Variazione nel ${filters.year}`,
    };
  }

  if (monthName) {
    return {
      amount: `Importo di ${monthName}`,
      count: `Accrediti di ${monthName}`,
      average: `Media di ${monthName}`,
      variation: `Variazione di ${monthName}`,
    };
  }

  return {
    amount: "Importo complessivo",
    count: "Accrediti complessivi",
    average: "Media complessiva",
    variation: "Variazione mensile",
  };
}

export default function AccreditsPage() {
  const [searchParams] = useSearchParams();
  const [accredits, setAccredits] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [causes, setCauses] = useState([]);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [fields, setFields] = useState(emptyForm);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState({ text: "", error: false });
  const [listFilters, setListFilters] = useState({ dateFrom: "", dateTo: "", causeId: "" });

  const globalFilters = useMemo(() => {
    const defaults = currentMonthFilters();
    return {
      accountId: searchParams.has("account") ? searchParams.get("account") : defaults.accountId,
      month: "",
      year: searchParams.get("year") || defaults.year,
    };
  }, [searchParams]);

  useEffect(() => {
    Promise.all([getAccredits(), getAccounts(), getManagedItems("cause")])
      .then(([accreditData, accountData, causeData]) => {
        setAccredits(accreditData);
        setAccounts(accountData);
        setCauses(causeData);
      })
      .catch((error) => setMessage({ text: errorMessage(error, "Impossibile caricare i dati."), error: true }))
      .finally(() => setLoading(false));
  }, []);

  const scopedAccredits = useMemo(() => accredits.filter((item) => {
    const date = String(item.movementDate);
    if (globalFilters.accountId && String(item.accountId) !== globalFilters.accountId) return false;
    if (globalFilters.month && date.slice(5, 7) !== globalFilters.month) return false;
    if (globalFilters.year && date.slice(0, 4) !== globalFilters.year) return false;
    return true;
  }), [accredits, globalFilters]);

  const visibleAccredits = useMemo(() => scopedAccredits.filter((item) => {
    const date = String(item.movementDate).slice(0, 10);
    if (listFilters.dateFrom && date < listFilters.dateFrom) return false;
    if (listFilters.dateTo && date > listFilters.dateTo) return false;
    if (listFilters.causeId && String(item.causeId) !== listFilters.causeId) return false;
    return true;
  }).sort((first, second) => String(second.movementDate).localeCompare(String(first.movementDate)) || second.id - first.id), [listFilters, scopedAccredits]);

  const metrics = useMemo(() => {
    const total = scopedAccredits.reduce((sum, item) => sum + Number(item.amount), 0);
    const today = localDate();
    const comparisonYear = globalFilters.year || today.slice(0, 4);
    const comparisonMonth = globalFilters.month || today.slice(5, 7);
    const currentKey = `${comparisonYear}-${comparisonMonth}`;
    const previousKey = shiftedMonthKey(comparisonYear, comparisonMonth, -1);
    const comparisonPool = globalFilters.accountId
      ? accredits.filter((item) => String(item.accountId) === globalFilters.accountId)
      : accredits;
    const currentMonth = comparisonPool.filter((item) => monthKey(item.movementDate) === currentKey).reduce((sum, item) => sum + Number(item.amount), 0);
    const previousMonth = comparisonPool.filter((item) => monthKey(item.movementDate) === previousKey).reduce((sum, item) => sum + Number(item.amount), 0);
    const byAccount = Object.values(scopedAccredits.reduce((result, item) => {
      const key = item.accountId;
      result[key] ??= { accountId: key, accountName: item.accountName, accountColor: item.accountColor, count: 0, total: 0 };
      result[key].count += 1;
      result[key].total += Number(item.amount);
      return result;
    }, {})).sort((first, second) => second.total - first.total);
    return {
      total,
      count: scopedAccredits.length,
      average: scopedAccredits.length ? total / scopedAccredits.length : 0,
      currentMonth,
      previousMonth,
      currentPeriodLabel: monthKeyLabel(currentKey),
      previousPeriodLabel: monthKeyLabel(previousKey),
      difference: currentMonth - previousMonth,
      percentage: previousMonth ? ((currentMonth - previousMonth) / previousMonth) * 100 : null,
      byAccount,
    };
  }, [accredits, globalFilters, scopedAccredits]);

  function openNew() {
    const today = localDate();
    const selectedYear = globalFilters.year || today.slice(0, 4);
    const selectedMonth = globalFilters.month || today.slice(5, 7);
    const selectedDay = selectedYear === today.slice(0, 4) && selectedMonth === today.slice(5, 7) ? today.slice(8, 10) : "01";
    setEditing(null);
    setFields({ ...emptyForm(), accountId: globalFilters.accountId, movementDate: `${selectedYear}-${selectedMonth}-${selectedDay}` });
    setFormOpen(true);
    setMessage({ text: "", error: false });
  }

  function openEdit(item) {
    setEditing(item);
    setFields({ movementDate: String(item.movementDate).slice(0, 10), amount: item.amount, accountId: String(item.accountId), causeId: item.causeId ? String(item.causeId) : "", notes: item.notes ?? "" });
    setFormOpen(true);
    setMessage({ text: "", error: false });
  }

  function closeForm() {
    setFormOpen(false);
    setEditing(null);
  }

  async function save(event) {
    event.preventDefault();
    setSaving(true);
    try {
      const saved = editing ? await updateAccredit(editing.id, fields) : await createAccredit(fields);
      setAccredits((current) => {
        const next = editing ? current.map((item) => (item.id === saved.id ? saved : item)) : [saved, ...current];
        return next.sort((first, second) => String(second.movementDate).localeCompare(String(first.movementDate)) || second.id - first.id);
      });
      closeForm();
      setMessage({ text: "Accredito salvato correttamente.", error: false });
    } catch (error) {
      setMessage({ text: errorMessage(error, "Impossibile salvare l'accredito."), error: true });
    } finally {
      setSaving(false);
    }
  }

  async function confirmDelete() {
    setSaving(true);
    try {
      await deleteAccredit(deleting.id);
      setAccredits((current) => current.filter((item) => item.id !== deleting.id));
      setMessage({ text: "Accredito eliminato.", error: false });
    } catch (error) {
      setMessage({ text: errorMessage(error, "Impossibile eliminare l'accredito."), error: true });
    } finally {
      setDeleting(null);
      setSaving(false);
    }
  }

  const activeCauses = causes.filter((cause) => cause.active || String(cause.id) === fields.causeId);
  const selectedAccount = accounts.find((account) => String(account.id) === globalFilters.accountId);
  const statisticLabels = periodStatisticLabels(globalFilters);

  if (!globalFilters.accountId) {
    return <AccreditsOverview accounts={accounts} accredits={accredits} loading={loading} message={message} />;
  }

  return (
    <div className="mx-auto max-w-6xl">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div className="min-w-0">
          <Link to="/accounting/accredits" className="mb-2 inline-flex items-center gap-1 text-xs text-slate-500 hover:text-amber-700"><ArrowLeftIcon className="h-3.5 w-3.5" />Tutti i conti</Link>
          <div className="flex items-center gap-3">
            <span className="h-3 w-3 shrink-0 rounded-full" style={{ backgroundColor: selectedAccount?.color || "#64748b" }} />
            <h1 className="text-3xl font-bold" style={{ color: selectedAccount?.color || "#0f172a" }}>{selectedAccount?.name ?? "Conto"}</h1>
          </div>
          <p className="mt-2 text-slate-500">Accrediti, andamento e importi dell'anno.</p>
        </div>
        <div className="max-w-full overflow-x-auto pb-1 lg:ml-auto">
          <div className="ml-auto flex w-max flex-nowrap items-center gap-2">
            <span className="flex h-9 items-center rounded-md border border-slate-300 bg-white px-3 text-[11px] font-semibold uppercase tracking-wide text-slate-600">Anno {globalFilters.year}</span>
            <button type="button" onClick={openNew} className="flex h-9 shrink-0 items-center justify-center gap-1.5 whitespace-nowrap rounded-md bg-amber-500 px-4 text-sm font-semibold text-white transition-colors hover:bg-amber-600">
              <PlusIcon className="h-4 w-4" /> Nuovo accredito
            </button>
          </div>
        </div>
      </div>

      {message.text && <p className={`mt-6 rounded-md px-4 py-3 text-sm font-medium ${message.error ? "bg-red-50 text-red-700" : "bg-emerald-50 text-emerald-700"}`}>{message.text}</p>}

      {formOpen && (
        <form onSubmit={save} className="mt-8 rounded-lg border border-slate-200 bg-white p-8">
          <h2 className="text-xl font-semibold text-slate-900">{editing ? "Modifica accredito" : "Nuovo accredito"}</h2>
          <div className="mt-6 grid grid-cols-1 gap-6 md:grid-cols-2">
            <label className="text-sm font-medium text-slate-700">Data accredito *<input type="date" required value={fields.movementDate} onChange={(event) => setFields((current) => ({ ...current, movementDate: event.target.value }))} className="mt-2 w-full rounded-md border border-slate-300 px-4 py-3 outline-none focus:border-amber-500" /></label>
            <label className="text-sm font-medium text-slate-700">Importo accredito *<input type="number" required min="0.01" step="0.01" value={fields.amount} onChange={(event) => setFields((current) => ({ ...current, amount: event.target.value }))} placeholder="0,00" className="mt-2 w-full rounded-md border border-slate-300 px-4 py-3 outline-none focus:border-amber-500" /></label>
            <div className="text-sm font-medium text-slate-700">Conto / banca<div className="mt-2 flex min-h-12 w-full items-center gap-3 rounded-md border border-slate-200 bg-slate-50 px-4 text-sm font-semibold" style={{ color: selectedAccount?.color || "#334155" }}><span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ backgroundColor: selectedAccount?.color || "#64748b" }} />{selectedAccount?.name}{selectedAccount?.bank ? ` · ${selectedAccount.bank}` : ""}</div></div>
            <label className="text-sm font-medium text-slate-700">Causale accredito *<select required value={fields.causeId} onChange={(event) => setFields((current) => ({ ...current, causeId: event.target.value }))} className="mt-2 w-full rounded-md border border-slate-300 bg-white px-4 py-3 outline-none focus:border-amber-500"><option value="">Seleziona una causale</option>{activeCauses.map((cause) => <option key={cause.id} value={cause.id}>{cause.name}</option>)}</select><Link to="/settings/causes" className="mt-2 inline-block text-xs text-amber-700 hover:text-amber-900">Gestisci causali</Link></label>
            <label className="text-sm font-medium text-slate-700 md:col-span-2">Note<textarea rows="3" value={fields.notes} onChange={(event) => setFields((current) => ({ ...current, notes: event.target.value }))} placeholder="Nota facoltativa" className="mt-2 w-full rounded-md border border-slate-300 px-4 py-3 outline-none focus:border-amber-500" /></label>
          </div>
          <div className="mt-8 flex justify-end gap-3"><button type="button" onClick={closeForm} className="rounded-md border border-slate-300 px-6 py-3 font-semibold text-slate-700 hover:bg-slate-50">Annulla</button><button type="submit" disabled={saving || !selectedAccount || activeCauses.length === 0} className="rounded-md bg-amber-500 px-6 py-3 font-semibold text-white hover:bg-amber-600 disabled:opacity-60">{saving ? "Salvataggio..." : "Salva accredito"}</button></div>
        </form>
      )}

      <div className="mt-5 grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
        <MetricCard label={statisticLabels.amount} value={currency.format(metrics.total)} icon={BanknotesIcon} />
        <MetricCard label={statisticLabels.count} value={String(metrics.count)} icon={CalculatorIcon} />
        <MetricCard label={statisticLabels.average} value={currency.format(metrics.average)} icon={CalculatorIcon} />
        <MetricCard
          label={`Variazione ${metrics.currentPeriodLabel}`}
          value={`${metrics.difference >= 0 ? "+" : ""}${currency.format(metrics.difference)}`}
          detail={`Rispetto a ${metrics.previousPeriodLabel}: ${currency.format(metrics.previousMonth)}${metrics.percentage === null ? "" : ` · ${metrics.percentage >= 0 ? "+" : ""}${metrics.percentage.toFixed(1)}%`}`}
          icon={metrics.difference < 0 ? ExclamationTriangleIcon : metrics.difference > 0 ? ArrowTrendingUpIcon : CalculatorIcon}
          tone={metrics.difference < 0 ? "danger" : metrics.difference > 0 ? "success" : "neutral"}
        />
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2 rounded-lg border border-slate-200 bg-white px-3 py-2.5">
        <h2 className="mr-1 shrink-0 text-[11px] font-semibold uppercase tracking-wide text-slate-500">Per conto</h2>
        {metrics.byAccount.length ? metrics.byAccount.map((account) => (
          <div key={account.accountId} className="flex items-center gap-2 rounded-md border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs">
            <span className="h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: account.accountColor || "#64748b" }} />
            <span className="font-semibold" style={{ color: account.accountColor || "#475569" }}>{account.accountName}</span>
            <span className="text-slate-400">{account.count}</span>
            <strong className="tabular-nums text-slate-800">{currency.format(account.total)}</strong>
          </div>
        )) : <p className="text-xs text-slate-400">Nessun accredito nel periodo</p>}
      </div>

      <div className="mt-4 overflow-hidden rounded-lg border border-slate-200 bg-white">
        <div className="border-b border-slate-200 px-6 py-5">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div><h2 className="text-lg font-semibold text-slate-900">Storico accrediti</h2><p className="mt-1 text-sm text-slate-500">{visibleAccredits.length} risultati nel periodo selezionato.</p></div>
            <div className="flex flex-wrap items-end gap-2">
              <FilterField label="Dal"><input type="date" value={listFilters.dateFrom} onChange={(event) => setListFilters((current) => ({ ...current, dateFrom: event.target.value }))} className="h-8 rounded-md border border-slate-300 px-2 text-xs outline-none focus:border-amber-500" /></FilterField>
              <FilterField label="Al"><input type="date" value={listFilters.dateTo} onChange={(event) => setListFilters((current) => ({ ...current, dateTo: event.target.value }))} className="h-8 rounded-md border border-slate-300 px-2 text-xs outline-none focus:border-amber-500" /></FilterField>
              <FilterField label="Causale"><FilterSelect compact ariaLabel="Filtra storico per causale" value={listFilters.causeId} onChange={(event) => setListFilters((current) => ({ ...current, causeId: event.target.value }))}><option value="">Tutte</option>{causes.map((cause) => <option key={cause.id} value={cause.id}>{cause.name}</option>)}</FilterSelect></FilterField>
              {(listFilters.dateFrom || listFilters.dateTo || listFilters.causeId) && <button type="button" onClick={() => setListFilters({ dateFrom: "", dateTo: "", causeId: "" })} className="h-8 rounded-md border border-slate-300 px-3 text-xs text-slate-600 hover:bg-slate-50">Azzera</button>}
            </div>
          </div>
        </div>

        {loading ? <p className="px-6 py-5 text-sm text-slate-500">Caricamento...</p> : visibleAccredits.length ? (
          <div className="overflow-x-auto">
            <div className="min-w-[760px]">
              <div className="grid grid-cols-[120px_minmax(160px,1fr)_minmax(180px,1fr)_130px_72px] items-center gap-4 border-b border-slate-200 bg-slate-50 px-5 py-2 text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                <span>Data</span><span>Conto</span><span>Causale</span><span className="text-right">Importo</span><span />
              </div>
              <div className="divide-y divide-slate-100">
                {visibleAccredits.map((item) => (
                  <div key={item.id} title={item.notes || undefined} className="grid grid-cols-[120px_minmax(160px,1fr)_minmax(180px,1fr)_130px_72px] items-center gap-4 px-5 py-2.5 text-[13px]">
                    <span className="tabular-nums text-slate-500">{dateFormatter.format(new Date(`${String(item.movementDate).slice(0, 10)}T00:00:00`))}</span>
                    <span className="flex min-w-0 items-center gap-2 font-semibold" style={{ color: item.accountColor || "#475569" }}><span className="h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: item.accountColor || "#64748b" }} /><span className="truncate">{item.accountName}</span></span>
                    <span className="truncate text-slate-700">{item.causeName}</span>
                    <strong className="text-right tabular-nums text-slate-900">{currency.format(Number(item.amount))}</strong>
                    <div className="flex items-center justify-end gap-1"><button type="button" onClick={() => openEdit(item)} aria-label={`Modifica accredito ${item.causeName}`} className="flex h-7 w-7 items-center justify-center rounded-md text-slate-500 hover:bg-amber-50 hover:text-amber-700"><PencilSquareIcon className="h-4 w-4" /></button><button type="button" onClick={() => setDeleting(item)} aria-label={`Elimina accredito ${item.causeName}`} className="flex h-7 w-7 items-center justify-center rounded-md text-red-500 hover:bg-red-50 hover:text-red-700"><TrashIcon className="h-4 w-4" /></button></div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : <p className="px-6 py-8 text-center text-sm text-slate-400">Nessun accredito corrisponde ai filtri</p>}
      </div>

      {deleting && <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/40 p-6"><div className="w-full max-w-md rounded-lg border border-slate-200 bg-white p-8"><h2 className="text-xl font-semibold text-slate-900">Eliminare l'accredito?</h2><p className="mt-3 text-sm text-slate-600">L'accredito di <strong>{currency.format(Number(deleting.amount))}</strong> verrà eliminato definitivamente.</p><div className="mt-8 flex justify-end gap-3"><button type="button" onClick={() => setDeleting(null)} disabled={saving} className="rounded-md border border-slate-300 px-5 py-3 font-semibold text-slate-700 hover:bg-slate-50">Annulla</button><button type="button" onClick={confirmDelete} disabled={saving} className="rounded-md bg-red-600 px-5 py-3 font-semibold text-white hover:bg-red-700 disabled:opacity-60">{saving ? "Eliminazione..." : "Elimina"}</button></div></div></div>}
    </div>
  );
}

function MetricCard({ label, value, detail, icon: Icon, tone = "default" }) {
  const danger = tone === "danger";
  const success = tone === "success";
  return (
    <div role={danger ? "alert" : undefined} className={`rounded-lg border px-4 py-3 ${danger ? "border-red-300 bg-red-50" : "border-slate-200 bg-white"}`}>
      <div className="flex items-center justify-between"><p className={`text-[10px] font-medium uppercase tracking-wide ${danger ? "text-red-600" : "text-slate-400"}`}>{label}</p><Icon className={`h-4 w-4 ${danger ? "text-red-600" : success ? "text-emerald-600" : "text-amber-600"}`} /></div>
      <p className={`mt-1.5 text-xl font-semibold ${danger ? "text-red-700" : "text-slate-900"}`}>{value}</p>
      {detail && <p className={`mt-0.5 truncate text-[10px] ${danger ? "text-red-600" : success ? "text-emerald-600" : "text-slate-500"}`}>{detail}</p>}
    </div>
  );
}

function FilterSelect({ ariaLabel, value, onChange, children, compact = false, widthClass = "w-32" }) {
  return (
    <div className="relative shrink-0">
      <select
        aria-label={ariaLabel}
        value={value}
        onChange={onChange}
        className={`appearance-none truncate rounded-md border border-slate-300 bg-white pl-2.5 pr-7 text-slate-700 outline-none transition-colors hover:border-slate-400 focus:border-amber-500 ${widthClass} ${compact ? "h-8 text-xs" : "h-9 text-xs"}`}
      >
        {children}
      </select>
      <ChevronDownIcon className="pointer-events-none absolute right-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
    </div>
  );
}

function FilterField({ label, children }) {
  return <label className="flex flex-col gap-1 text-[10px] font-medium uppercase tracking-wide text-slate-400">{label}{children}</label>;
}

function AccreditsOverview({ accounts, accredits, loading, message }) {
  const today = localDate();
  const year = today.slice(0, 4);
  const month = today.slice(5, 7);
  const period = `${year}-${month}`;
  const current = accredits.filter((item) => monthKey(item.movementDate) === period);
  const total = current.reduce((sum, item) => sum + Number(item.amount), 0);
  const summaries = accounts.filter((account) => account.active).map((account) => {
    const rows = current.filter((item) => String(item.accountId) === String(account.id));
    return { account, count: rows.length, total: rows.reduce((sum, item) => sum + Number(item.amount), 0) };
  });
  const periodLabel = monthKeyLabel(period);

  return (
    <div className="mx-auto max-w-6xl">
      <div className="flex items-center gap-3"><BanknotesIcon className="h-8 w-8 text-amber-500" /><h1 className="text-3xl font-bold text-slate-900">Accrediti</h1></div>
      <p className="mt-2 text-slate-500">Situazione generale di {periodLabel}. Scegli un conto per gestire accrediti, mesi e anni.</p>
      {message.text && <p className={`mt-5 rounded-md px-4 py-3 text-sm ${message.error ? "bg-red-50 text-red-700" : "bg-emerald-50 text-emerald-700"}`}>{message.text}</p>}
      <div className="mt-5 grid grid-cols-1 gap-3 md:grid-cols-3">
        <MetricCard label={`Importo di ${periodLabel}`} value={currency.format(total)} icon={BanknotesIcon} />
        <MetricCard label={`Accrediti di ${periodLabel}`} value={String(current.length)} icon={CalculatorIcon} />
        <MetricCard label={`Media di ${periodLabel}`} value={currency.format(current.length ? total / current.length : 0)} icon={CalculatorIcon} />
      </div>
      <div className="mt-5 overflow-hidden rounded-lg border border-slate-200 bg-white">
        <div className="border-b border-slate-200 px-5 py-3"><h2 className="text-sm font-semibold text-slate-900">Conti</h2><p className="mt-0.5 text-xs text-slate-500">Ogni conto conserva una gestione separata per mese e anno.</p></div>
        {loading ? <p className="px-5 py-5 text-sm text-slate-500">Caricamento...</p> : <div className="divide-y divide-slate-100">{summaries.map(({ account, count, total: accountTotal }) => {
          const color = account.color || "#64748b";
          return <Link key={account.id} to={`/accounting/accredits?account=${account.id}&year=${year}`} className="grid grid-cols-[1fr_auto_auto_auto] items-center gap-6 px-5 py-3 transition-colors hover:bg-amber-50"><span className="flex min-w-0 items-center gap-3 font-semibold" style={{ color }}><span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ backgroundColor: color }} /><span className="truncate">{account.name}</span></span><span className="text-xs text-slate-400">{count} accrediti</span><strong className="text-sm tabular-nums text-slate-900">{currency.format(accountTotal)}</strong><ChevronRightIcon className="h-4 w-4 text-slate-400" /></Link>;
        })}</div>}
      </div>
    </div>
  );
}
