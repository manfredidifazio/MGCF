import { Menu } from "@headlessui/react";
import { Fragment } from "react";
import {
  Bars3BottomLeftIcon,
  BuildingLibraryIcon,
  ChevronDownIcon,
  Cog6ToothIcon,
  HomeModernIcon,
  ReceiptPercentIcon,
  TruckIcon,
} from "@heroicons/react/24/outline";
import { useNavigate } from "react-router-dom";

const items = [
  { label: "Conti", icon: BuildingLibraryIcon, path: "/settings/accounts" },
  { label: "Tasse", icon: ReceiptPercentIcon },
  { label: "Immobili", icon: HomeModernIcon },
  { label: "Veicoli", icon: TruckIcon },
  { label: "Causali", icon: Bars3BottomLeftIcon },
];

export default function SettingsMenu() {
  const navigate = useNavigate();

  return (
    <Menu as="div" className="relative inline-block">
      <Menu.Button className="flex h-8 w-full items-center gap-2 rounded-md border border-slate-200 bg-white px-3 text-[12px] font-medium tracking-wide text-slate-700 transition-colors duration-150 hover:border-amber-300 hover:bg-amber-50 hover:text-slate-900">
        <Cog6ToothIcon className="h-[18px] w-[18px] text-amber-600" />
        <span>IMPOSTAZIONI</span>
        <ChevronDownIcon className="h-3.5 w-3.5 text-slate-400" />
      </Menu.Button>

      <Menu.Items className="absolute inset-x-0 z-50 mt-1.5 w-full overflow-hidden rounded-md border border-slate-200 bg-white py-1.5 focus:outline-none">
        {items.map((item, index) => {
          const Icon = item.icon;

          return (
            <Fragment key={item.label}>
              {index > 0 && <div className="mx-3 border-t border-slate-200" />}
              <Menu.Item>
                {({ focus }) => (
                  <button
                    type="button"
                    onClick={() => item.path && navigate(item.path)}
                    className={`flex w-full items-center gap-3 px-3 py-2.5 text-left text-[13px] font-normal transition-colors duration-150 ${focus ? "bg-amber-50 text-amber-900" : "text-slate-700"}`}
                  >
                    <Icon className="h-[18px] w-[18px] shrink-0 text-slate-500" />
                    <span>{item.label}</span>
                  </button>
                )}
              </Menu.Item>
            </Fragment>
          );
        })}
      </Menu.Items>
    </Menu>
  );
}
