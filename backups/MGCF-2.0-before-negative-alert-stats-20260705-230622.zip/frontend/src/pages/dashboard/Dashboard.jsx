export default function Dashboard() {
  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="text-2xl font-bold">
        Dashboard MGCF
      </h1>

      <p className="mt-2 text-slate-600">
        Login avvenuto correttamente
      </p>
    </div>
  );
}
