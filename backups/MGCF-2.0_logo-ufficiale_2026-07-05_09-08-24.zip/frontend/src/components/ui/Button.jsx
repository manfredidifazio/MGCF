export default function Button({
  children,
  type = "button",
  onClick,
  fullWidth = false,
  variant = "primary",
  disabled = false,
}) {
  const styles = {
    primary:
      "bg-amber-600 text-white hover:bg-amber-700 shadow-lg shadow-amber-600/20",
    secondary:
      "bg-slate-100 text-slate-700 hover:bg-slate-200",
  };

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`
        h-12
        rounded-2xl
        px-6
        font-semibold
        transition-all
        duration-200
        active:scale-95
        disabled:cursor-not-allowed
        disabled:opacity-60
        ${styles[variant]}
        ${fullWidth ? "w-full" : ""}
      `}
    >
      {children}
    </button>
  );
}
