import { Outlet } from "react-router-dom";
import NavigationBar from "../components/navigation/NavigationBar";
import Topbar from "../components/topbar/Topbar";

export default function MainLayout() {
  return (
    <div className="min-h-screen bg-[#f7f6f3]">

      {/* TOPBAR */}
      <Topbar />
      <NavigationBar />

      <div className="flex">

        {/* SIDEBAR */}
        <aside className="min-h-[calc(100vh-96px)] w-72 border-r border-slate-200 bg-white">
        </aside>

        {/* CONTENUTO */}
        <main className="flex-1 p-8">
          <Outlet />
        </main>

      </div>

    </div>
  );
}
