import {
  ArrowLeftIcon,
  ArrowRightIcon,
  ChevronRightIcon,
  MagnifyingGlassIcon,
} from "@heroicons/react/24/outline";
import { useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

const pages = [
  {
    label: "Dashboard",
    path: "/dashboard",
    keywords: "home dashboard panoramica principale riepilogo",
  },
  {
    label: "Impostazioni",
    path: "/settings",
    keywords: "impostazioni configurazione gestione preferenze",
  },
  {
    label: "Conti",
    path: "/settings/accounts",
    keywords: "conti conto banca bancario saldo accrediti",
  },
  {
    label: "Sicurezza",
    path: "/security",
    keywords: "sicurezza password parola ordine accesso domande recupero",
  },
];

const breadcrumbMap = {
  "/dashboard": [{ label: "Home", path: "/dashboard" }],
  "/security": [
    { label: "Home", path: "/dashboard" },
    { label: "Sicurezza", path: "/security" },
  ],
  "/settings": [
    { label: "Home", path: "/dashboard" },
    { label: "Impostazioni", path: "/settings" },
  ],
  "/settings/accounts": [
    { label: "Home", path: "/dashboard" },
    { label: "Impostazioni", path: "/settings" },
    { label: "Conti", path: "/settings/accounts" },
  ],
};

function normalize(value) {
  return value
    .toLocaleLowerCase("it")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim();
}

export function NavigationTrail() {
  const location = useLocation();
  const navigate = useNavigate();
  const breadcrumbs = breadcrumbMap[location.pathname] ?? [
    { label: "Home", path: "/dashboard" },
  ];

  return (
    <div className="flex min-w-0 flex-1 items-center gap-3">
      <div className="flex shrink-0 items-center gap-1">
        <button
          type="button"
          onClick={() => navigate(-1)}
          aria-label="Pagina precedente"
          title="Indietro"
          className="flex h-7 w-7 items-center justify-center rounded-md border border-slate-200 bg-white text-slate-600 transition-colors hover:border-amber-300 hover:text-amber-700"
        >
          <ArrowLeftIcon className="h-4 w-4" />
        </button>
        <button
          type="button"
          onClick={() => navigate(1)}
          aria-label="Pagina successiva"
          title="Avanti"
          className="flex h-7 w-7 items-center justify-center rounded-md border border-slate-200 bg-white text-slate-600 transition-colors hover:border-amber-300 hover:text-amber-700"
        >
          <ArrowRightIcon className="h-4 w-4" />
        </button>
      </div>

      <nav aria-label="Percorso pagina" className="flex min-w-0 flex-1 items-center gap-1.5 overflow-hidden text-[12px] text-slate-500">
        {breadcrumbs.map((item, index) => (
          <span key={`${item.label}-${index}`} className="flex min-w-0 items-center gap-1.5">
            {index > 0 && <ChevronRightIcon className="h-3.5 w-3.5 shrink-0 text-slate-400" />}
            {item.path ? (
              <button
                type="button"
                onClick={() => navigate(item.path)}
                aria-current={index === breadcrumbs.length - 1 ? "page" : undefined}
                className={`truncate transition-colors hover:text-amber-700 ${index === breadcrumbs.length - 1 ? "text-slate-700" : ""}`}
              >
                {item.label}
              </button>
            ) : (
              <span className={`truncate ${index === breadcrumbs.length - 1 ? "text-slate-700" : ""}`}>
                {item.label}
              </span>
            )}
          </span>
        ))}
      </nav>
    </div>
  );
}

export function PageSearch() {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [searchFocused, setSearchFocused] = useState(false);

  const results = useMemo(() => {
    const terms = normalize(query).split(/\s+/).filter(Boolean);

    if (terms.length === 0) return [];

    return pages.filter((page) => {
      const searchable = normalize(`${page.label} ${page.keywords}`);
      return terms.every((term) => searchable.includes(term));
    });
  }, [query]);

  function openPage(page) {
    navigate(page.path);
    setQuery("");
    setSearchFocused(false);
  }

  function handleSubmit(event) {
    event.preventDefault();
    if (results[0]) openPage(results[0]);
  }

  return (
    <form onSubmit={handleSubmit} className="relative w-56 shrink-0">
      <MagnifyingGlassIcon className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
      <input
        type="search"
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        onFocus={() => setSearchFocused(true)}
        onBlur={() => setSearchFocused(false)}
        placeholder="Cerca una pagina..."
        aria-label="Cerca una pagina"
        className="h-8 w-full rounded-md border border-slate-200 bg-white pl-8 pr-3 text-[12px] text-slate-700 outline-none transition-colors placeholder:text-slate-400 focus:border-amber-400"
      />

      {searchFocused && query.trim() && (
        <div className="absolute right-0 top-full z-50 mt-1 w-full overflow-hidden rounded-md border border-slate-200 bg-white py-1">
          {results.length > 0 ? (
            results.map((page) => (
              <button
                key={page.path}
                type="button"
                onMouseDown={(event) => event.preventDefault()}
                onClick={() => openPage(page)}
                className="flex w-full items-center px-3 py-2 text-left text-[12px] text-slate-700 transition-colors hover:bg-amber-50 hover:text-amber-900"
              >
                {page.label}
              </button>
            ))
          ) : (
            <p className="px-3 py-2 text-[12px] text-slate-400">Nessuna pagina trovata</p>
          )}
        </div>
      )}
    </form>
  );
}
