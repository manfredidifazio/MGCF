import { useEffect, useState } from "react";

import PageMask from "../../components/layout/PageMask";
import { deleteAdminUser, getAdminUsers, updateAdminUser } from "../../services/adminUserService";

export default function AdminUsersPage() {
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState("");

  async function loadUsers(value = search) {
    const result = await getAdminUsers(value);
    setUsers(result);
  }

  useEffect(() => {
    getAdminUsers("").then(setUsers);
  }, []);

  async function patch(user, fields) {
    await updateAdminUser(user.id, { ...user, ...fields });
    await loadUsers();
  }

  async function remove(id) {
    if (!confirm("Eliminare questo utente?")) return;
    await deleteAdminUser(id);
    await loadUsers();
  }

  return (
    <PageMask title="Amministrazione utenti" description="Gestisci utenti, ruoli, stato account e accessi.">
      <div className="mb-3 flex gap-2">
        <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Cerca utente..." className="h-9 rounded-md border border-slate-300 px-3 text-sm outline-none focus:border-amber-500" />
        <button type="button" onClick={() => loadUsers()} className="rounded-md border border-slate-300 px-4 text-sm">Cerca</button>
      </div>
      <div className="overflow-x-auto rounded-lg border border-slate-200 bg-white">
        <div className="min-w-[900px]">
          <div className="grid grid-cols-[180px_240px_130px_100px_150px_150px_120px] gap-4 border-b border-slate-200 bg-slate-50 px-5 py-2 text-[10px] font-semibold uppercase tracking-wide text-slate-400">
            <span>Nome</span><span>Email</span><span>Ruolo</span><span>Stato</span><span>Registrazione</span><span>Ultimo accesso</span><span className="text-right">Azioni</span>
          </div>
          <div className="divide-y divide-slate-100">
            {users.map((user) => (
              <div key={user.id} className="grid grid-cols-[180px_240px_130px_100px_150px_150px_120px] items-center gap-4 px-5 py-2.5 text-[13px]">
                <span className="font-semibold">{user.username}</span>
                <span className="truncate text-slate-500">{user.email}</span>
                <button type="button" onClick={() => patch(user, { role: user.role === "Administrator" ? "User" : "Administrator" })} className="text-left text-amber-700">{user.role}</button>
                <button type="button" onClick={() => patch(user, { isActive: !user.isActive })} className={user.isActive ? "text-emerald-700" : "text-red-600"}>{user.isActive ? "Attivo" : "Bloccato"}</button>
                <span className="text-slate-500">{user.createdAt ? new Date(user.createdAt).toLocaleDateString("it-IT") : "—"}</span>
                <span className="text-slate-500">{user.lastLogin ? new Date(user.lastLogin).toLocaleDateString("it-IT") : "—"}</span>
                <button type="button" onClick={() => remove(user.id)} className="text-right text-red-600">Elimina</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </PageMask>
  );
}
