import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:5000",
});

export async function getSecurity() {
  const { data } = await api.get("/security");
  return data;
}

export async function updateSecurityAnswers(
  middleSchoolAnswer,
  dogNameAnswer
) {
  const { data } = await api.put("/security", {
    middleSchoolAnswer,
    dogNameAnswer,
  });

  return data;
}

export async function updatePassword(currentPassword, newPassword) {
  const { data } = await api.put("/security/password", {
    currentPassword,
    newPassword,
  });

  return data;
}
