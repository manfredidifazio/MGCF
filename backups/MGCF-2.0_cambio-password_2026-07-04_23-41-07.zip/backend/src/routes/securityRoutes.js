import { Router } from "express";

import {
  changePassword,
  getSecurity,
  saveSecurity,
} from "../controllers/securityController.js";

const router = Router();

router.get("/", getSecurity);
router.put("/", saveSecurity);
router.put("/password", changePassword);

export default router;
